'use strict';
mainApp.directive('quickAccessMenu', function () {
	return {
		restrict: 'A',
		link: function (scope, elem, attrs, $rootscope) {
			elem.on('mouseenter', function () {
				elem.css({
					'z-index': '999'
				});
				elem.removeClass('ovf-hidden');
				/*elem.children('#quickAccess').addClass('pt-page-rotatePullTop');*/
				scope.slideDownMenu();

			});

			elem.on('mouseleave', function () {
				elem.css({
					'z-index': '4'
				});
				elem.addClass('ovf-hidden');
				/* elem.children('#quickAccess').removeClass('pt-page-rotatePullTop');*/
				scope.hideMenu();

			});
			scope.$on("$destroy", function () {
				elem.off('mouseenter');
				elem.off('mouseleave');
			});

		}
	};
});

mainApp.directive('appSave', function($rootScope, OpenSaveService){
    return {
        restrict: 'A',
        link: function(scope, elem, attrs){
            elem.on('change', function(event, cb) {
                var filePath = elem.val();
                OpenSaveService.fileToSave = filePath;
                var directoryPath = filePath.substring(0, filePath.lastIndexOf('\\'));
                $rootScope.$broadcast('setExportPathLocation', directoryPath);
                
                filePath = filePath.replace(/\\/g, '\\\\');                
                OpenSaveService.save();
                elem.val("");
            });
            scope.$on("$destroy", function(){
                elem.off('change');
            });
                
        }
    };
});

mainApp.directive('appLoad', function(OpenSaveService){
    return {
        restrict: 'A',
        link: function(scope, elem, attrs){
            elem.on('change', function(evt) {                
                OpenSaveService.openFile(elem.val());
                elem.val('');
            });
            
            scope.$on("$destroy", function(){
                elem.off('change');
            });
                
        }
    };
});

//
// This directive will be used whenever NW FileDialog is used
// It registers the change event and upon a file is chosen
// obtains the directory and path details and calls the respective
// function which is passed as attribute
//
mainApp.directive('nwFileDialog', function ($parse) {
	return {
		restrict: 'A',
		link: function (scope, elm, attrs) {
			elm.bind('change', function () {
				if (attrs.ngModel) {
					$parse(attrs.ngModel).assign(scope, elm[0].files[0]);
				}
				var filePath = elm[0].files[0].path;
				var fileDelimiterIndex = filePath.lastIndexOf('\\');
				var directoryPath = filePath.substring(0, fileDelimiterIndex);
				// scope.pathLocationForFileDialog['filePath'] = directoryPath;

				// persistState.saveState(introDatabase.getDBName(),
				// 	scope, 'pathForFileDialog', ['pathLocationForFileDialog'],
				// 	'appstate', undefined,
				// 	function () {

				// 	});
				//
				// Make a copy of information which we wanted and 
				// pass it to the handler function which is in attributes
				// 
				var file = {};
				file.name = elm[0].files[0].name;
				file.path = elm[0].files[0].path;

				//
				// File path chosen must be made empty by setting
				// the value property empty because
				// when next time same file is chosen - change 
				// event will not be called. Known issue in NW
				// https://github.com/nwjs/nw.js/wiki/File-dialogs
				//
				elm[0].value = '';
				$parse(attrs.nwFileDialog)(scope, {
					nwFile: file
				});
			});

			scope.$on('$destroy', function () {
				elm.unbind('change');
			});
		}
	};
});
