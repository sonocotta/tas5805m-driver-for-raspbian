mainApp.service("OpenSaveService", function ($rootScope, $q, configDataService, StatusMessageService){

     var fs = require('fs');
    var path = require('path');
    var self = this;
    $rootScope.openSave = {};
    $rootScope.openSave.error = '';
    $rootScope.openSave.saveAsFromMenu = function() {
        var saveDialog = $('#saveDBDialog');
        saveDialog.trigger('click');
    };
    $rootScope.openSave.saveFromMenu = function() {
        if(!self.fileToSave){
            $rootScope.saveAsFromMenu();
        }
    };

    this.readFile = function(filePath) {
        var defered = $q.defer();
        filePath = path.resolve(filePath);
        this.fileToSave = filePath;

        var ext = path.extname(path.basename(filePath));
        if(ext.toLowerCase() !== '.json') {
            defered.reject('Not a valid file');
            return defered.promise;
        }
        
        fs.readFile(filePath, 'utf8',function (err, data) {
            if (err) {
               defered.reject(err);
             }
             else {
                 try {
                     var jsonDataArray = [];
                     jsonDataArray.push(JSON.parse(data));
                     defered.resolve(jsonDataArray);
                 }
                 catch (err) {
                     defered.reject("Not a valid JSON");
                 }
             }
         })
        return defered.promise;
    };
    var checkIfProperData = function(data){
        if(data[0].version && data[0].settings){
            return true;
        }
        return false;
    };
    var versionCompare = function(version, fileVersion){
        var result = {};
        result.pluginVersionIsLess = true;
        version = version.split('.');
        fileVersion = fileVersion.split('.');
        if(version[0] > fileVersion[0]){
            result.pluginVersionIsLess = false;
        } else if(version[0] == fileVersion[0]){
            if(version[1] > fileVersion[1]) {
                result.pluginVersionIsLess = false;
            } else if(version[1] == fileVersion[1]){
                if(version[2]>= fileVersion[2]){
                    result.pluginVersionIsLess = false;
                }
            }
        }
        return result;
    };
    this.checkIfAppIsLowerVersion = function(data){
        var result = {};
        if(!data[0].version) {
            return false;
        }
        pluginVersion = $rootScope.appGlobals.appVersion;
        var PPC3Version = data[0].version;
        
        result = versionCompare(pluginVersion, PPC3Version);        
        return result;
    };
    var importDataToApp = function(data){
        configDataService.init();
        var allSettings = configDataService.getBinaryObject();
        allSettings.loadData(data[0].settings);
    };
    var setCurrentFile = function(filePath){
        $rootScope.openSave.currentFile = path.basename(filePath);
    };
    var clearCurrentFile = function(){
        $rootScope.openSave.currentFile = '';
    };
    var checkingDeviceValues = function(data) {
        var dataToBeChecked = angular.copy(data);
        if(dataToBeChecked[0].settings.amplifierType.length > 1) {
            dataToBeChecked[0].settings.configurationList.forEach(function(item) {
                item.blocksList.forEach(function(value) {
                    var deviceValueFromAmpName = configDataService.getDeviceValueFromAmpName(value.deviceName);
                    if(deviceValueFromAmpName !== parseInt(value.deviceValue)) {
                        value.deviceValue = deviceValueFromAmpName;
                    }
                })
            })
        }
        return dataToBeChecked;

    };
    this.openFile = function(filePath) {
        $rootScope.openSave.inProgress = true;
        StatusMessageService.information('Loading file');
        try {
            self.readFile(filePath).then(function(data) {                 
                /* Check the version number of the plugin with PPC3 file before importing */
                if(checkIfProperData(data)){
                    var versionCheck = self.checkIfAppIsLowerVersion(data);
                    if(versionCheck.pluginVersionIsLess){
                        $rootScope.openSave.inProgress = false;
                        $rootScope.openSave.error ='The selected file version is not supported by the current version of the App and cannot be opened. Please upgrade the App to use this file';
                        self.fileToSave = '';
                        clearCurrentFile();
                        StatusMessageService.error('File is from a latest verison and cannot be opened');
                    }
                    else {
                        data = checkingDeviceValues(data);
                        importDataToApp(data);
                        setCurrentFile(filePath);
                        $rootScope.$broadcast('appReload');
                        StatusMessageService.success('File loaded successfully');
                    }
                } else {
                    $rootScope.openSave.inProgress = false;
                    self.fileToSave = '';
                    clearCurrentFile();
                    StatusMessageService.error('File does not contain proper data to load');
                }
            }).finally(function() {
                $rootScope.openSave.inProgress = false;
            });              
        } catch(exp) {
            $rootScope.openSave.inProgress = false;
            StatusMessageService.information('Failed to load file');
            self.fileToSave = '';
            clearCurrentFile();
        }
      };
      var writeDatatoFile = function(){
        var defered = $q.defer();
        var data = {};
        data.version = $rootScope.appGlobals.appVersion;
        data.settings = configDataService.getBinaryObject();
        var jsonData = JSON.stringify(data, null, 4);
        fs.writeFile(self.fileToSave, jsonData, function(err){
            if(!err) {
                defered.resolve();
            }
            else {
            defered.reject(err);
        }});
        return defered.promise;
      };
      this.save = function() {
          var self = this;
        $rootScope.saveInProgress = true;
        StatusMessageService.information('Saving settings to file');
        return writeDatatoFile()
        .then(function(){
            $rootScope.saveInProgress = false;
            StatusMessageService.success("Successfully saved file");
            setCurrentFile(self.fileToSave);
        },function(err) {
            $rootScope.saveInProgress = false;
            StatusMessageService.error("Failed to save file");
            console.log(err);
            clearCurrentFile();
        })
        .finally(function(){
            if($rootScope.openSave.funcToCall){
                $rootScope.openSave.funcToCall();
                $rootScope.openSave.funcToCall = undefined;
            }
        });
    };
    this.closeApp = function(){
        $rootScope.$broadcast('appClose');
    };
    this.newSession = function(){
        $rootScope.openSave.newSession = false;
        StatusMessageService.information('opening new session', 1500);
        configDataService.clearConfigurationSettings();
        configDataService.clearHWSettings();
        $rootScope.$broadcast('newSession');
        clearCurrentFile();
    };
});