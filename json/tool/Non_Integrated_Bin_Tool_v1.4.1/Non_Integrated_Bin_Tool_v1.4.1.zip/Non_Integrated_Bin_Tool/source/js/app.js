var gui = require('nw.gui');
var win = gui.Window.get();
win.setTransparent(!win.isTransparent);
win.setTransparent(!win.isTransparent)
// win.showDevTools();

var mainApp = angular.module('mainApp', [
    'ngRoute'    
]);

mainApp.config(['$routeProvider',
    function($routeProvider){
        $routeProvider.when('/homepage', {
            templateUrl:'../homepage/views/html/homepage.html',
            controller: "homePageController",
            resolve:{
                deps:function($q, $rootScope){
                    var deferred = $q.defer();
                    var dependencies = ['../homepage/controller/homepage.controller.js'];

                    requirejs(dependencies, function()
                    {                        
                        deferred.resolve();
                    });
                    return deferred.promise;
                }
            }
        });

        $routeProvider.when('/configurationpage', {
            templateUrl:'../configurationpage/views/html/configurationpage.html',
            controller: "configurationPageController",
            resolve:{
                deps:function($q, $rootScope){
                    var deferred = $q.defer();
                    var dependencies = ['../configurationpage/controller/configurationpage.controller.js'];

                    requirejs(dependencies, function()
                    {                        
                        deferred.resolve();
                    });
                    return deferred.promise;
                }
            }
        });

        $routeProvider.otherwise({
            redirectTo: '/homepage'
        });
    }]).run(function($rootScope) {
        $rootScope.appGlobals = {};
        $rootScope.appGlobals.statusInformation = {};
        $rootScope.appGlobals.appVersion = gui.App.manifest.version;
    });

    mainApp.directive('hexValidator', [function () {
        return {
            restrict: 'A',
            require: 'ngModel',
            priority: 1,
            link: function (scope, elem, attrs, ngModel) {
                console.log(scope);
                elem.bind('blur', function () {
                    ngModel.$setValidity('hexValidator', true);
                    if (ngModel.$viewValue !== ngModel.$modelValue) {
                        ngModel.$viewValue = ngModel.$modelValue;
                        ngModel.$render();
                    }
                });
                var verify = function(val) {
                    var re = /[0-9A-Fa-f]{1,2}/g
                    // var val = elem[0].value;
                    val = val.trimLeft();
                    if(val.length > 2) {
                        // elem.addClass("error-textbox");
                        ngModel.$setValidity('hexValidator', false);
                        return ngModel.$modelValue;
                    } else {
                        var matchValue = val.match(re);
                        if(matchValue === null) {
                            // elem.addClass("error-textbox");
                            ngModel.$setValidity('hexValidator', false);
                            return ngModel.$modelValue;
                        }                    
                        else if(matchValue[0].length !== val.length) {
                            // elem.addClass("error-textbox");
                            ngModel.$setValidity('hexValidator', false);
                            return ngModel.$modelValue;
                        } else {
                            ngModel.$setValidity('hexValidator', true);
                            return val;
                            // elem.removeClass("error-textbox");
                        }
                    }
                   
                }               

                ngModel.$parsers.unshift(verify);

                scope.$on("$destroy", function () {
                    elem.unbind('blur');
                });
            }
        };
    }]);

    mainApp.directive('hexTextAreaValidator', [function () {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function (scope, elem, attrs, ngModel) {
                console.log(scope);
                elem.bind('blur', function () {
                    ngModel.$setValidity('hexTextAreaValidator', true);
                    if (ngModel.$viewValue !== ngModel.$modelValue) {
                        ngModel.$viewValue = ngModel.$modelValue;
                        ngModel.$render();
                    }
                });
                var verify = function(val) {
                    var re = /[0-9A-Fa-f\s]{1,2}/g
                    var val = elem[0].value;
                    val = val.trimLeft();
                    if(val === '') {
                        // elem.removeClass("error-textbox");
                        ngModel.$setValidity('hexTextAreaValidator', true);
                        return val;
                    } else {
                        var matchValue = val.match(re);
                        if(matchValue === null) {
                            // elem.addClass("error-textbox");
                            ngModel.$setValidity('hexTextAreaValidator', false);
                            return ngModel.$modelValue;;
                        }
                        else if(matchValue.join('').length !== val.length) {
                            // elem.addClass("error-textbox");
                            ngModel.$setValidity('hexTextAreaValidator', false);
                        }
                        else {
                            var values = val.split(' ');
                            for(var i=0; i<values.length; i++) {
                                var x = parseInt(values[i], 16)
                                if(isNaN(x)){
                                    // elem.addClass("error-textbox");
                                    ngModel.$setValidity('hexTextAreaValidator', false);
                                    return ngModel.$modelValue;;
                                } else if(x > 255){
                                    // elem.addClass("error-textbox");
                                    ngModel.$setValidity('hexTextAreaValidator', false);
                                    return ngModel.$modelValue;;
                                }
                            }
                            // elem.removeClass("error-textbox");
                            ngModel.$setValidity('hexTextAreaValidator', true);
                            return val;
                        }

                    }
                }

                ngModel.$parsers.unshift(verify);

                scope.$on("$destroy", function () {
                    elem.unbind('blur');
                });
            }
        };
    }]);    

    mainApp.directive('rangeValidator', [function () {
        return {
            restrict: 'A',
            require: 'ngModel',
            priority: 1,
            link: function (scope, elem, attrs, ngModel) {
                var range = scope.$eval(attrs.rangeValidator);
                var min = range.min;
                var max = range.max
                elem.bind('blur', function () {
                    ngModel.$setValidity('rangeValidator', true);
                    if (ngModel.$viewValue !== ngModel.$modelValue) {
                        ngModel.$viewValue = ngModel.$modelValue;
                        ngModel.$render();
                    }
                });

                var isNumber = function(n) {
                    return !isNaN(parseFloat(n)) && isFinite(n);
                };
    
                var verify = function (value) {
                    range = scope.$eval(attrs.rangeValidator);
                    min = range.min;
                    max = range.max
                    if (isNumber(value)) {
                        if (value < min) {
                            value = min;
                            ngModel.$setValidity('rangeValidator', false);
                        } else if (value > max) {
                            value = max;
                            ngModel.$setValidity('rangeValidator', false);
                        } else {
                            ngModel.$setValidity('rangeValidator', true);
                        }
                        return parseFloat(value);
                    } else {
                        ngModel.$setValidity('rangeValidator', false);
                        return ngModel.$modelValue;
                    }
                };
                ngModel.$parsers.unshift(verify);
    
                scope.$on("$destroy", function () {
                    elem.unbind('blur');
                });
            }
        };
    }]);

    mainApp.directive('focusThis', ['$timeout', '$parse', function ($timeout, $parse) {
        // Reference: https://stackoverflow.com/questions/14833326/how-to-set-focus-on-input-field
        return {
            link: function (scope, element, attrs) {
                var model = $parse(attrs.focusThis);
                scope.$watch(model, function (value) {
                    if (value === true) {
                        // $timeout seems to be needed to give the modal time to render
                        $timeout(function () {
                            element[0].focus();
                        });
                    }
                });
                // on blur event:
                element.bind('blur', function () {
                    console.log('blur');
                    scope.$apply(model.assign(scope, false));
                });
            }
        };
    }]);



