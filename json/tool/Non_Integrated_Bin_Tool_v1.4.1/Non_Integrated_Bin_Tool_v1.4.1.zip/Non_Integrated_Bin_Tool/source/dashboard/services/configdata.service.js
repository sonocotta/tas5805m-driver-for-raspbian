mainApp.service("configDataService", function($q) {

    var fs = require('fs');
    var initDone = false;
    var configData = {};
    var storedHardwareSetupDetails = {};
    var binarySettings;

    this.init = function() {
        if(!initDone) {
            var filePath = "./source/settings/configData.json";
            var data = fs.readFileSync(filePath);
            configData = JSON.parse(data);
            initDone = true
            console.log(configData);
            binarySettings = new Binary(configData);
        }
    }

    this.getConfigData = function() {
        return configData;
    }

    this.getBinaryObject = function() {
        return binarySettings;
    }

    this.clearConfigurationSettings = function() {
        binarySettings.clearConfigData();
    }
    this.clearHWSettings = function() {
        binarySettings.clearHWSetupSettings();
    }

    this.storeHWSetupSettings = function(data) {
        // storedHardwareSetupDetails['platform'] = platform;
        // storedHardwareSetupDetails['noOfDevices'] = noOfDevices;
        // storedHardwareSetupDetails['deviceMappings'] = deviceMappings;
        binarySettings.platformType = data.selectedPlatform;
        binarySettings.devicesCount = data.selectedNumOfDevices;
        binarySettings.amplifierType = data.deviceMappings;
        binarySettings.deviceType = data.selectedDeviceType;
    };

    this.getSettings = function() {
        var settings = {};
        settings['platform'] = binarySettings.platformType;
        settings['noOfDevices'] = binarySettings.devicesCount;
        settings['deviceMappings'] = binarySettings.amplifierType;
        settings['deviceType'] = binarySettings.deviceType;
        return settings;
    }

    this.getPlatformTypes = function() {
        return Object.keys(configData.types.platformType.values);
    }

    this.getDeviceCounts = function() {
        return Object.keys(configData.types.deviceCount.values).filter(function (devCount) {
            if (binarySettings.deviceType === "Integrated") {
                var devCountNum = devCount.split(" ")[0];
                if (Number(devCountNum) < 2) {
                    return devCount;
                }
            } else {
                return devCount;
            }
        });
    }

    this.getAmpTypes = function() {
        return Object.keys(configData.types.amplifierType.values).filter(function(ampType) {
            var supportedAmpTypes = ["TAS2783"];
            if(binarySettings.deviceType === "Integrated") {
                if(supportedAmpTypes.indexOf(ampType) !== -1)  {
                    return ampType;
                }
            } else {
                if(supportedAmpTypes.indexOf(ampType) === -1) {
                    return ampType;
                }
            }
        })
    }

    this.getHardwareSetupDetails = function() {
        var hardwareDetails = {};
        hardwareDetails['availablePlatforms'] = this.getPlatformTypes();
        hardwareDetails['numberOfDevices'] = this.getDeviceCounts();
        hardwareDetails['availableAmplifiers'] = this.getAmpTypes();
        hardwareDetails['availableDeviceTypes'] = configData.types.deviceType.availableDeviceTypes;
        return hardwareDetails
    }

    this.getBlockTypes = function() {
        return Object.keys(configData.types.blockType.values);
    }

    this.getAmpNamesWithIndex = function() {        
        var selectedAmps = binarySettings.amplifierType;
        var renamedList = selectedAmps.map(function(amp, ind) {
            return "Dev " + (ind + 1) + " - " + amp; 
        });
        if(renamedList.length >  1) {
            renamedList.splice(0, 0, "Common");  
        }
        return renamedList;
    }

    this.getDeviceValueFromAmpName = function (ampName) {
        var ampNameArray = ampName.split(" ");
        return parseInt(ampNameArray[1]); 
    }

});