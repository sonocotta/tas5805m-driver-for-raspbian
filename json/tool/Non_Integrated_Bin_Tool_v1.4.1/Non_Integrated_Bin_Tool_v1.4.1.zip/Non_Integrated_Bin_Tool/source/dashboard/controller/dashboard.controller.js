mainApp.controller("dashboardController", function($scope, $rootScope, $location, $q, configDataService, OpenSaveService) {
    var gui = require('nw.gui');
    var win = gui.Window.get();   

    $scope.maximizeGUI = function() {
        NodeWebkitControl.maximizeWindow();
    };

    $scope.minimizeGUI = function() {
        NodeWebkitControl.minimizeWindow();
    };
    $rootScope.menu = {};
    $scope.closeApp = function() {
        $rootScope.menu.showClosePopup = true;
        $rootScope.openSave.funcToCall = OpenSaveService.closeApp.bind(OpenSaveService);
    };

    $scope.closeOrReopenGUI = function(forceClose) {
        if(forceClose || !$rootScope.openSave.newSession){
            NodeWebkitControl.closeWindow();
        } else {
            $rootScope.openSave.funcToCall();
            $rootScope.openSave.funcToCall = undefined;
            $rootScope.menu.showClosePopup = false;
        }
    };

    $scope.cancelAppClose = function(){
        $rootScope.menu.showClosePopup = false;
    };

    $scope.isAppMaximized = function() {
        if (win.isFullscreen && process.platform == 'darwin') {
        return true;
        }
        return false;
    };

    $scope.closeSnackBar = function() {
        $rootScope.appGlobals.statusInformation = {};
    }
    
    $rootScope.menu.visibility = false;
    $scope.hideMenu = function(){
        $rootScope.menu.visibility = false;
    }
    $scope.slideDownMenu = function(){
        $rootScope.menu.visibility = true;
    }

    function initialize() {
        configDataService.init();
    }

    initialize();

    $scope.loadingInProgress = false;
    $rootScope.setLoadingProgress = function(val) {
        $scope.loadingInProgress = val;
    }
    $scope.saveAsFromMenu = function() {
        var saveDialog = $('#saveDBDialog');
        saveDialog.trigger('click');
    };


    $scope.openFromMenu = function() {
        var openDialog = $('#openDialog');
        openDialog.trigger('click');
    };
    
    $scope.newFromMenu = function() {
       $scope.hideMenu();
       $rootScope.menu.showClosePopup = true;
       $rootScope.openSave.newSession = true;
       $rootScope.openSave.funcToCall = OpenSaveService.newSession.bind(OpenSaveService);
    };

    $scope.saveFromMenu = function() {
        $rootScope.menu.showClosePopup = false;
        if(!OpenSaveService.fileToSave){
            $scope.saveAsFromMenu();
        }
        else {
            OpenSaveService.save();
        }
    };

    $scope.saveAndClose = function(){
        $scope.saveFromMenu();
    };

    $rootScope.$on('appClose', function(){
        $scope.closeOrReopenGUI(true);
    });

    $scope.setDirectoryPath = function(value) {
        if(value.files[0] && value.files[0].path) {
            $scope.settingsFolderPath = value.files[0].path;
            window.localStorage.setItem("NON_INTEG-settingsFolderPath", $scope.settingsFolderPath);
        }
        $scope.$digest();
    };

    $scope.initializeWorkingDirectory = function() {
        var fs = require('fs');
        var folder = window.localStorage.getItem("NON_INTEG-settingsFolderPath");
        if(folder != null && folder != undefined && fs.existsSync(folder)) {
            $scope.settingsFolderPath = folder;
        } else {
            $scope.settingsFolderPath = '';
        }
    };

    $scope.getFileName = function(){
        if($rootScope.openSave.currentFile){
            return '('+$rootScope.openSave.currentFile+ ')';
        } else {
            return '';
        }
    };

    $scope.initializeWorkingDirectory();
});