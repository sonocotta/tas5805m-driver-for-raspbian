// var sysIntegrationModule = angular.module("sysIntegrationModule");
/*constants for config-selection page*/
mainApp.constant('configSelection', {
    totalDDC : 5,
    totalSnaps : 10,
    totalQuadSnaps: 64,
    samplingFrequencyList : {
        'ROM Mode': [
            { fs : '48 KHz', fsAssumed : '48 KHz'},
        ],
        'ROM Mode 1': [
            { fs : '48 KHz', fsAssumed : '48 KHz'},
            { fs : '44.1 KHz', fsAssumed : '44.1 KHz'},
        ],
        'ROM Mode 2': [
            { fs : '48 KHz', fsAssumed : '48 KHz'},
            { fs : '44.1 KHz', fsAssumed : '44.1 KHz'},
        ],
        'ROM Mode 1 96KHz': [
            { fs : '96 KHz', fsAssumed : '48 KHz'},
        ],
        'ROM Mode 2 96KHz': [
            { fs : '96 KHz', fsAssumed : '48 KHz'},
        ],
        'RAM Mode': [
            { fs : '48 KHz', fsAssumed : '48 KHz'},
            { fs : '44.1 KHz', fsAssumed : '44.1 KHz'},
        ],
        'Tuning Mode': [
            { fs : '48 KHz', fsAssumed : '48 KHz'},
            { fs : '32 KHz', fsAssumed : '32 KHz'},
            { fs : '16 KHz', fsAssumed : '48 KHz'}
            // { fs : '8 KHz', fsAssumed : '48 KHz'},
            // { fs : '44.1 KHz', fsAssumed : '44.1 KHz'},
        ]
    },
    clockConfigurations: {
        'TAS2563QFN':{
            'ROM Mode': ["Auto"],
            'Tuning Mode': ["Auto", "BCLK 1.536 MHz", "BCLK 3.072 MHz", "BCLK 12.288 MHz"]
        },
        'Default':{
            'ROM Mode': ["Auto"],
            'Tuning Mode': ["Auto"]
        }
    }
});

mainApp.constant('regDumpHexStrConst', {
    book: '0x7f',
    page: '0x00',
    burst: '0x85',
    delay: '0x81'
});

mainApp.constant('defaultFtcfg', {
    'ftcSettings': {
        'FTC_BYPASS': 0,
    },
    'advanced': {
        'CALIBRATION_TIME': 2000,
        'VERIFICATION_TIME': 4000,
    },
    'passFailLimits': {
        'RE_HI': 7.975,
        'RE_LO': 6.525,
        'F0_HI': 924,
        'F0_LO': 616,
        'Q_HI': 1.704,
        'Q_LO': 1.136,
        'T_HI': 40,
        'T_LO': 0,
    },
    'speakerManufacturer': {
        'SPK_RE_TOL_PER': 10,
    }
});

mainApp.constant('systemIntegrationEnums', {
    'sysConnectModes': {
        CURRENT_STATE: 'current-state',
        DDC: 'ddc'
    },
    'cfgGenModes': {
        BIN_DEBUG: 'binDebug',
        SRTS: 'srts',
        DOWNLOAD_CURRENT_STATE: 'download-current-state'
    }
});

mainApp.constant('binaryFormatConstants', {
    options: ['git.ti.com', 'kernel.org']
});

mainApp.constant('endSystemOptions', {
    options: ['Mobile phone', 'Windows PC', 'Smartwatch', 'Other'],
    windowsAudioModes: ['Raw', 'Default', 'Movie', 'Media', 'Speech', 'Communication', 'Notification'],
    devOrientation: ['Portrait', 'Landscape', 'Portrait Flipped', 'Landscape Flipped']
});

mainApp.constant('adbVersionOptions', {
    "v1.0.32":{
        "folderName": "v32",
        "adbRoot":{
            "mode" : "run",
            "response" : "as root"
        },
        "adbWait":{
            "mode" : "runSilent",
            "timeout": 200
        },
        "adbRemount":{
            "mode": "run",
            "response": "succeeded"
        },
        "adbPush":{
            "mode": "runPush"
        },
        "adbChmod":{
            "mode" : "runSilent",
            "timeout": 200
        },
        "adbForward":{
            "mode" : "runSilent",
            "timeout": 200
        },
        "rccd2Start":{
            "mode" : "runIgnore",
            "timeout": 200
        },
        "rccd2Kill":{
            "mode" : "runIgnore",
            "timeout": 200
        }
    },
    "v1.0.40":{
        "folderName": "v40",
        "adbRoot":{
            "mode" : "runIgnore",
            "timeout": 200
        },
        "adbWait":{
            "mode" : "runSilent",
            "timeout": 200
        },
        "adbRemount":{
            "mode": "run",
            "response": "succeeded"
        },
        "adbPush":{
            "mode": "run",
            "response": "pushed"
        },
        "adbChmod":{
            "mode" : "runSilent",
            "timeout": 200
        },
        "adbForward":{
            "mode" : "runSilent",
            "timeout": 200
        },
        "rccd2Start":{
            "mode" : "runIgnore",
            "timeout": 200
        },
        "rccd2Kill":{
            "mode" : "runIgnore",
            "timeout": 200
        }
    }
});
