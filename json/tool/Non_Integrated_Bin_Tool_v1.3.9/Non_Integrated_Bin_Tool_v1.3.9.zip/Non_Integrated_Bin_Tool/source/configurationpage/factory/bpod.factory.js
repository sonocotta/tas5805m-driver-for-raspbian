mainApp.factory('Bpod', [function () {
    "use strict";

    var cmds = {
        DELAY:  (254),
        BURST:  (253),
        SET  :  (252),
        WAIT :  (251),
        SLAVE:  (250),
        READ:   (249),
        BREAK:  (248),
        GPIO:	(247),
        XMOS:	(246)
    };

    function toBpodCommand(data, writes) {
        return {
            "book": data.book[data.slave],
            "page": data.page[data.slave],
            "slave": data.slave,
            "offset": data.offset,
            "data": writes,
        };
    }

    function updateData(data, writes) {
        if(data.offset === 0 ) {
            data.page[data.slave] = writes.shift();
            data.offset++;
        } else if(data.offset === 127 && data.page[data.slave] === 0) {
            data.book[data.slave] = writes.shift();
            data.offset++;
        }
        return data;
    }

    function toDelay(command) {
        var delay = command.shift();
        return {"delay": delay};
    }

    function fromBlock(blockCommands) {
        var data = {
            'page': {},
            'book': {},
            'slave': 0,
        };
        var writes, command;
        var bpodCommands = [];
        for (var i = 0; i < blockCommands.length; i++) {
            command = blockCommands[i].slice();
            switch (command[0]) {
                case cmds.READ:
                    // currently the READ commands are not supported
                    break;
                case cmds.DELAY:
                    command.shift(); // type
                    bpodCommands.push(toDelay(command));
                    break;
                case cmds.SLAVE:
                    command.shift(); // type
                    data.slave = command.shift();
                    break;
                case cmds.BURST:
                    command.shift(); // type
                    var len = command.shift(); // burstLength
                    data.offset = command.shift();
                    if(len == 1) {
                        writes = [command.shift()];
                    } else {
                        writes = command.shift();
                    }
                    data = updateData(data, writes);
                    if(writes.length) {
                        bpodCommands.push(
                            toBpodCommand(data, writes)
                        );
                    }
                    break;
                default:
                    data.offset = command.shift();
                    writes = [command.shift()];
                    data = updateData(data, writes);
                    if (writes.length) {
                        bpodCommands.push(
                            toBpodCommand(data, writes)
                        );
                    }
                    break;
            }
        }
        return bpodCommands;
    }

    function Bpod(blockCommands) {
        this.commands = fromBlock(blockCommands);
    }

    return Bpod;

}]);
