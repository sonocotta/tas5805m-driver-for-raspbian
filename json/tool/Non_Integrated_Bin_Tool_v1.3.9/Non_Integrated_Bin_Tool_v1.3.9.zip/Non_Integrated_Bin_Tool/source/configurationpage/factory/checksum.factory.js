mainApp.factory('Checksum', ['$injector', function ($injector) {
    "use strict";

    var CHECKSUM_CONFIG = {
      "PRAM": {},
      "YRAM": {}
    };

    function Checksum(bpodCommands) {
        this.bpodCommands = bpodCommands;
    }

    function getRange(a, b) {
        var range = [];
        for (var i = a; i <= b; i++) {
            range.push(i);
        }
        return range;
    }

    function extractConfig(config) {

        function rangeExtractor(ele) {
            var splits = ele.split("-");
            if(splits.length === 1) {
                return parseInt(splits[0], 16);
            }
            return getRange(
                parseInt(splits[0], 16),
                parseInt(splits[1], 16)
            );
        }

        function extract(list) {
            var extracted = list.map(rangeExtractor);
            return extracted.reduce(function (accumulator, ele) {
                return accumulator.concat(ele);
            }, []);
        }

        var completePages, regs = {};
        var page, decPage;
        completePages = extract(config.completePages);
        for (page in config.regs) {
            decPage = parseInt(page, 16);
            regs[decPage] = extract(config.regs[page]);
        }

        return {
            "completePages": completePages,
            "regs": regs
        };
    }

    // polynomial: 0x4D
    var CRC8_LOOKUP_TABLE = [
        0x00, 0x4D, 0x9A, 0xD7, 0x79, 0x34, 0xE3, 0xAE,
        0xF2, 0xBF, 0x68, 0x25, 0x8B, 0xC6, 0x11, 0x5C,
        0xA9, 0xE4, 0x33, 0x7E, 0xD0, 0x9D, 0x4A, 0x07,
        0x5B, 0x16, 0xC1, 0x8C, 0x22, 0x6F, 0xB8, 0xF5,
        0x1F, 0x52, 0x85, 0xC8, 0x66, 0x2B, 0xFC, 0xB1,
        0xED, 0xA0, 0x77, 0x3A, 0x94, 0xD9, 0x0E, 0x43,
        0xB6, 0xFB, 0x2C, 0x61, 0xCF, 0x82, 0x55, 0x18,
        0x44, 0x09, 0xDE, 0x93, 0x3D, 0x70, 0xA7, 0xEA,
        0x3E, 0x73, 0xA4, 0xE9, 0x47, 0x0A, 0xDD, 0x90,
        0xCC, 0x81, 0x56, 0x1B, 0xB5, 0xF8, 0x2F, 0x62,
        0x97, 0xDA, 0x0D, 0x40, 0xEE, 0xA3, 0x74, 0x39,
        0x65, 0x28, 0xFF, 0xB2, 0x1C, 0x51, 0x86, 0xCB,
        0x21, 0x6C, 0xBB, 0xF6, 0x58, 0x15, 0xC2, 0x8F,
        0xD3, 0x9E, 0x49, 0x04, 0xAA, 0xE7, 0x30, 0x7D,
        0x88, 0xC5, 0x12, 0x5F, 0xF1, 0xBC, 0x6B, 0x26,
        0x7A, 0x37, 0xE0, 0xAD, 0x03, 0x4E, 0x99, 0xD4,
        0x7C, 0x31, 0xE6, 0xAB, 0x05, 0x48, 0x9F, 0xD2,
        0x8E, 0xC3, 0x14, 0x59, 0xF7, 0xBA, 0x6D, 0x20,
        0xD5, 0x98, 0x4F, 0x02, 0xAC, 0xE1, 0x36, 0x7B,
        0x27, 0x6A, 0xBD, 0xF0, 0x5E, 0x13, 0xC4, 0x89,
        0x63, 0x2E, 0xF9, 0xB4, 0x1A, 0x57, 0x80, 0xCD,
        0x91, 0xDC, 0x0B, 0x46, 0xE8, 0xA5, 0x72, 0x3F,
        0xCA, 0x87, 0x50, 0x1D, 0xB3, 0xFE, 0x29, 0x64,
        0x38, 0x75, 0xA2, 0xEF, 0x41, 0x0C, 0xDB, 0x96,
        0x42, 0x0F, 0xD8, 0x95, 0x3B, 0x76, 0xA1, 0xEC,
        0xB0, 0xFD, 0x2A, 0x67, 0xC9, 0x84, 0x53, 0x1E,
        0xEB, 0xA6, 0x71, 0x3C, 0x92, 0xDF, 0x08, 0x45,
        0x19, 0x54, 0x83, 0xCE, 0x60, 0x2D, 0xFA, 0xB7,
        0x5D, 0x10, 0xC7, 0x8A, 0x24, 0x69, 0xBE, 0xF3,
        0xAF, 0xE2, 0x35, 0x78, 0xD6, 0x9B, 0x4C, 0x01,
        0xF4, 0xB9, 0x6E, 0x23, 0x8D, 0xC0, 0x17, 0x5A,
        0x06, 0x4B, 0x9C, 0xD1, 0x7F, 0x32, 0xE5, 0xA8
    ];

    function calculateCrc8Checksum(bytes) {
        /*
        * checksum = CRC8_LOOKUP_TABLE[(crc ^ data) & 0xff]
        * here, crc is 0.
        * So, checksum = CRC8_LOOKUP_TABLE[data & 0xff]
        */
        var len = bytes.length;
        var crcChecksum = 0;
        for (var i = 0; i < len; i++) {
            crcChecksum += CRC8_LOOKUP_TABLE[ bytes[i] & 0xff];
            //discard higher order bits
            crcChecksum = crcChecksum & 0xff;
        }
        return crcChecksum;
    }

    function getFilteredCmds(data, decBook) {
        return data.filter(function (cmd) {
            if(cmd.hasOwnProperty('book') && cmd.book === decBook ) {
                return cmd;
            }
        });
    }

    function filterValidWrites(cmd, regConfig) {
        var bytes = [];
        var pageConfig,
            offset = cmd.offset,
            page = cmd.page,
            completePages = regConfig.completePages,
            pages = Object.keys(regConfig.regs).map(Number),
            data = cmd.data;

        if (completePages.indexOf(page) !== -1) {
            return data;
        } else if (pages.indexOf(page) !== -1) {
            pageConfig = regConfig.regs[page];
            bytes = data.filter(function (regValue, index) {
                if(pageConfig.indexOf(offset + index) !== -1) {
                    return true;
                }
            });
        }
        return bytes;
    }

    function getValidBytes(cmds, regConfig ) {
        return cmds.reduce(function (bytes, cmd) {
            if(cmd.hasOwnProperty('book')) {
                bytes = bytes.concat(
                    filterValidWrites(cmd, regConfig)
                );
            }
            return bytes;
        }, []);
    }

    function generateBytesForBook(data, regConfig, decBook) {
        var filteredCmds;
        data = data.slice();
        filteredCmds = getFilteredCmds(data, decBook);
        return getValidBytes(filteredCmds, regConfig);
    }

    function getBytesFromBpod (commands, config) {
        if (config) {
            var decBooks = Object.keys(config).map(Number);
            var bookBytes = decBooks.map(function (book) {
                var decBook = book;
                return {
                    "book": decBook,
                    "bytes": generateBytesForBook(
                        commands, config[book], book )
                };
            });
            return bookBytes.reduce(function (collector, elem) {
                return collector.concat(elem.bytes);
            }, []);
        } else {
            return [];
        }
    }

    function extractChecksumConfig(config) {
        if (!Array.isArray(config)) {
            config = [];
        }
        var checksumConfig = {};
        config.forEach(function(elem) {
            var decBook = parseInt(elem.book, 16);
            checksumConfig[decBook] = extractConfig(elem);
        });
        return checksumConfig;
    }

    Checksum.getChecksumConfig = function () {
        return CHECKSUM_CONFIG;
    };

    Checksum.setChecksumConfig = function (config) {
      if(!Array.isArray(config[0])) {
          config[0] = [config[0]];
      }
      for (var i=0;i<config[0].length;i++){
        CHECKSUM_CONFIG.PRAM[i] = extractChecksumConfig(config[0][i].PRAM);
      }
    };

    Checksum.prototype.pramChecksum = function (deviceIndex) {
        var bytes = getBytesFromBpod(this.bpodCommands,
            CHECKSUM_CONFIG.PRAM[deviceIndex]);
        var checksumService = $injector.get("checksumService");
        if(bytes.length) {
            return checksumService.calculateChecksum(bytes);
        }
    };

    Checksum.prototype.yramChecksum = function (deviceIndex) {
        var bytes = getBytesFromBpod(this.bpodCommands,
            CHECKSUM_CONFIG.YRAM[deviceIndex]);
        if(bytes.length) {
            return calculateCrc8Checksum(bytes);
        }
    };

    return Checksum;

}]);
