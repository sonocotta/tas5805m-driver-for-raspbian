//assumed  - commands or book, page indicies will not be greater than a byte  (maximum is 'ff' - hex)
mainApp.service('binaryDump',["processBinary", 'Block', 'Block_V2', 'binConstants', 'blockType', 'KernelblockType', '$injector', 'binConfigFileNames', '$q',

        function(processBinary, Block, Block_V2, binConstants, blockType,KernelblockType, $injector, binConfigFileNames, $q) {

    'use strict';
    /*global fileOps*/
    // var $q = requireModuleService.getQModule();
    var fs = require('fs');
    var path = require('path');
    var eol = '\r\n';

    var RESERVED_BYTE = '00';

    var self = this;

    var binStructConfiguration;

    function updateBinConfig(binFormat, sysIntegData) {
        if(binStructConfiguration && binStructConfiguration.version === sysIntegData.binaryFormatVersion) {
            return $q.when(0);
        }
        //update binConfig 
        // var fileName = binFormat === 2 ?  binConfigFileNames["2."+sysIntegData.binaryFormatVersion] :  binConfigFileNames[sysIntegData.binaryFormatVersion];
        return fileOps.readJSONFile(path.join(process.cwd() + '/source/settings/binConfig_V2.json'))
        .then(function (binConfigJson) {
           binStructConfiguration = binConfigJson[0];
           binStructConfiguration.maxPrograms = sysIntegData.maxPrograms;
           binStructConfiguration.maxConfigurations = sysIntegData.maxConfigurations;
           enumsBin.device = binConfigJson[0].types.device.values;
           enumsBin.deviceType = binConfigJson[0].types.deviceType.values;
       });
    }

    var enumsBin = {
        "blockType": blockType
    };
    var enumsKernelBin = {
        "blockType": KernelblockType
    }
    var blockTypeReverseMap = (function (obj) {
        var revObj = createRevMap(obj);
        //change all keys to hex
        var newRevObj = {};
        for(var key in revObj) {
            newRevObj[parseInt(key, 16)] = revObj[key];
        }
        return newRevObj;
    })(enumsBin['blockType']);

    var KerenelblockTypeReverseMap = (function (obj) {
        var revObj = createRevMap(obj);
        //change all keys to hex
        var newRevObj = {};
        for(var key in revObj) {
            newRevObj[parseInt(key, 16)] = revObj[key];
        }
        return newRevObj;
    })(enumsKernelBin['blockType']);
    // NOTE - a copy of this func will be in processBinary.service, if you do any changes do it there as well
    function increaseByteSizeUptoFour(bytesTo, hexValStr) {
        //make sure hexValStr is proper - do not remove this
        hexValStr = toHexString(parseInt(hexValStr, 16));
        //increase the size
        var concatenatedStr = "00000000" + hexValStr;
        var finalStr = concatenatedStr.slice(-2*bytesTo);
        return finalStr;
    }

    function toHexString(num) {
        var hexString = num.toString(16);
        if(num < 16) {
            return "0" + hexString;
        }
        return hexString;
    }

    this.convertToHexStr = function (num, base) {
        base = base || 10;
        num = parseInt(num, base);
        if(isNaN(num)) {
            return;
        }
        return toHexString(num);
    };

    function initDumpData(dumpData) {
        dumpData = {
            'bin': []
        };
        return dumpData;
    }

    function parseRegLine(regLine) {
        var dumpParams = {};
        // Remove comment in the same line
        if(regLine.indexOf('#') !== -1) {
            regLine = regLine.substring(0, regLine.indexOf('#')).trim();
        }
        var splits = regLine.split('=');

        if (splits.length === 2) {
            dumpParams.data = splits[1].trim();
            splits = splits[0].split(',');

            var addresses = splits.pop().trim().split('-');

            if(addresses.length === 2) {
                dumpParams.start = addresses[0].trim();
                dumpParams.end = addresses[1].trim();
            } else if(addresses[0] === 'd') {
                dumpParams.delay = true;
            } else {
                dumpParams.start = dumpParams.end = addresses[0].trim();
            }

            if(splits.length > 0) {
                dumpParams.page = splits.pop().trim();
            }
            if(splits.length > 0) {
                dumpParams.book = splits.pop().trim();
            }
        }

        return dumpParams;
    }

    function strLineBin(hexBook, hexPage, hexOffset, hexValue) {
        return {
                book: hexBook,
                page: hexPage,
                offset: hexOffset,
                data: hexValue
        };
    }

    function dumpDelay(dumpData, delay) {
        var hexDelay = toHexString(delay);
        //to remove '0x' prefix from delayCmd
        var delayCmd = parseInt(regDumpHexStrConst.delay, 16);
        delayCmd = toHexString(delayCmd);
        //hexDelay should be 2 bytes, increase Size
        hexDelay = increaseByteSizeUptoFour(2, hexDelay);
        dumpData['bin'].push({
            param: hexDelay,
            command: delayCmd,
            reserved: RESERVED_BYTE
        });
    }

    function dumpLine(dumpData, params) {
        var hexSlave = toHexString(params.slaveAddress),
            hexOffset = toHexString(params.startAddress),
            hexValue = toHexString(params.value),
            hexBook = toHexString(params.book),
            hexPage = toHexString(params.page);

        // ignore book and page switch
        if((regDumpHexStrConst.book === ('0x'+hexOffset) && hexPage === '00') || regDumpHexStrConst.page === ('0x'+hexOffset)) {
            return; //skip book and page switch commands
        }
        dumpData['bin'].push(strLineBin(hexBook, hexPage, hexOffset, hexValue));
    }

    function strValuesBurstBin(params, dumpData) {
        var hexSlave = toHexString(params.slaveAddress),
            offset = params.startAddress,
            readVals = params.readVals,
            burstLength = params.burstLength,
            hexBook = toHexString(params.book),
            hexPage = toHexString(params.page);

        //to remove '0x' prefix from burtCmd
        var burstCmd = parseInt(regDumpHexStrConst.burst, 16);
        burstCmd = toHexString(burstCmd);

        function createBurstCmds(burstVals, burstArrIndex) {
            // update offset value
            var newOffset = offset + (burstArrIndex*burstLength);

            if(burstVals.length === 1) {
                params.startAddress = newOffset;
                params.readVals = burstVals;
                dumpValues(dumpData, params);
                return;
            }
            //burst command should be  4 bytes (increase size)
            var noOfRegs = toHexString(burstVals.length);
            noOfRegs = increaseByteSizeUptoFour(2, noOfRegs);
            //add burst command
            dumpData['bin'].push({
                param: noOfRegs,
                command: burstCmd,
                reserved: RESERVED_BYTE
            });
            var offsetLen = burstVals.length;
            var sizeOfEachCmd = 4, remainder = (offsetLen-1)%4;
            // each row should have n bytes, else append necessary zeroes
            if(remainder !== 0) {
                var offsetToAppend = 0;
                var offsetCountToAppend = sizeOfEachCmd-(remainder);
                while (offsetCountToAppend) {
                    burstVals.push(offsetToAppend);
                    --offsetCountToAppend;
                }
                offsetLen = burstVals.length;
            }
            var i = 0;
            var hexOffset = toHexString(newOffset + i);
            var hexValue = toHexString(burstVals[i]);
            // append burst Cmds
            dumpData['bin'].push(strLineBin(hexBook, hexPage, hexOffset, hexValue));
            ++i;
            while (i < offsetLen) {
                dumpData['bin'].push({
                    data0: toHexString(burstVals[i+0]),
                    data1: toHexString(burstVals[i+1]),
                    data2: toHexString(burstVals[i+2]),
                    data3: toHexString(burstVals[i+3])
                });
                i += 4;
            }
        }

        // split readVals by burstLength
        var readValsSplitByBurst = [], index = 0;
        while (readVals.length) {
            if(readVals.length >= burstLength) {
                readValsSplitByBurst[index] = readVals.splice(0, burstLength);
            } else {
                readValsSplitByBurst[index] = readVals.splice(0, readVals.length);
            }
            ++index;
        }
        // create busrt commands for splits
        readValsSplitByBurst.forEach(createBurstCmds);

        return dumpData['bin'];
    }

    function dumpValuesBurst(dumpData, params) {
        dumpData['bin']  = strValuesBurstBin(params, dumpData);
    }

    function dumpValues(dumpData, params) {
        var readVals = params.readVals,
            offset = params.startAddress;

        for(var i=0; i<readVals.length; i++) {
            params.startAddress = offset + i;
            params.value = readVals[i];
            dumpLine(dumpData, params);
        }
    }

    function readOffsets(params, data) {
        var deferred = $q.defer();

        try {
            var regLines,
            burst,
            dumpData,
            regBookForDump = 0, //should be initialized with zero
            regPageForDump = 0, //should be initialized with zero
            slaveAddress = params.i2cdec,
            ddfFile = params.dumpFormatFile,
            evmReference = DeviceManagerService.getDregs();

            // Read from file system if not available
            if(!data) {
                if(Array.isArray(ddfFile)) {
                    data = '';
                    for(var i in ddfFile) {
                        data += fs.readFileSync(ddfFile[i], 'utf8') + '\n';
                    }
                } else {
                     data = fs.readFileSync(ddfFile, 'utf8');
                }
            }

            dumpData = initDumpData(dumpData);
            regLines = data.split('\n');

            loopAsync(regLines.length, function (loop) {
                var l = loop.iteration(),
                    startAddress,
                    endAddress;

                if(regLines[l].charAt(0) === "#"){
                    loop.next();
                    return;
                }

                if(regLines[l].trim() === '') {
                    loop.next();
                    return;
                }

                var dumpParams = parseRegLine(regLines[l]);
                    if(!dumpParams.data) {
                        // There is no indication of data, so ignore the line from ddf,
                        loop.next();
                        return;
                    }

                    var addrArray = [];
                    if(dumpParams.hasOwnProperty('book')) {
                        addrArray.push(utils.toNumber(dumpParams.book));
                    }

                    if(dumpParams.hasOwnProperty('page')) {
                        addrArray.push(utils.toNumber(dumpParams.page));
                    }

                    if(dumpParams.hasOwnProperty('start')) {
                        startAddress = utils.toNumber(dumpParams.start);
                        addrArray.push(startAddress);
                    }

                    if(dumpParams.hasOwnProperty('end')) {
                        endAddress = utils.toNumber(dumpParams.end);
                    }

                    if(dumpParams.data !== 'xx') {
                        data = utils.toNumber(dumpParams.data);
                    }

                    //update book and page values
                    if(dumpParams.start === regDumpHexStrConst.book && regPageForDump === 0) {
                        regBookForDump = data;
                    } else if (dumpParams.start === regDumpHexStrConst.page) {
                        regPageForDump = data;
                    }

                    var dumpValuesParams = {
                        slaveAddress : slaveAddress,
                        startAddress : startAddress,
                        burstLength : params.burst,
                        book: regBookForDump,
                        value: data,
                        page: regPageForDump
                    };

                    if(!dumpParams.delay && dumpParams.data === 'xx') {
                        evmReference[params.device].readRegs(addrArray, endAddress - startAddress + 1).then(function(readVals){
                            dumpValuesParams.readVals = readVals;

                            if(!params.burst || params.burst <= 1 || readVals.length === 1) {
                                dumpValues(dumpData, dumpValuesParams);
                            }
                            else {
                                dumpValuesBurst(dumpData, dumpValuesParams);
                            }

                            loop.next();
                        });
                    } else if (dumpParams.delay) {
                        dumpDelay(dumpData, data);
                        loop.next();
                    } else {
                        dumpLine(dumpData, dumpValuesParams);
                        loop.next();
                    }
            },function () {
                //as assumed, each line of dev write (4 bytes) will be of strlen-8
                //before resolving convert to array ("of 8 chars each")
                deferred.resolve(dumpData['bin']);
            });
        } catch (e) {
            deferred.reject(e);
        }

        return deferred.promise;
    }

    this.dumpRegisterFromDDF = function (params, ddfStr) {
         return readOffsets(params, ddfStr);
    };

    function getCompleteBlocks(deviceName, device, sysIntegData) {
        if(sysIntegData.binaryFormat === 'kernel.org'){
            device.data.blockType = parseInt(enumsKernelBin['blockType'][deviceName], 16);
        }
        else{
            device.data.blockType = parseInt(enumsBin['blockType'][deviceName], 16);
        }
        
        return device;
    }

    function fitStrTolen(str, maxLen) {
        //truncate str to maxLen
        str = str.slice(0, maxLen);
        //append null if req
        while(str.length < maxLen) {
            str += '\0';
        }
        return str;
    }

    function giveMeProperName(str) {
        return fitStrTolen(str, 64);
    }

    function giveMeProperDescription(str) {
        return fitStrTolen(str, str.length+1);
    }

    function getEncodedVersion(version) {
        var versionArr = version.split('.');
        //first param in version will not be used
        var versionParams;
        var firstByte, secondByte, thirdByte;
        var thirdByte_last6Bits, thirdByte_first2Bits;
        var sixBitZeroes = '000000';
        //if version is stable,
        if(versionArr.length === 3) {
            secondByte = versionArr[2];
            thirdByte_first2Bits = '11';
            thirdByte_last6Bits = '000000';
        } else if(versionArr.length === 4) {
            //for unstable versions
            versionParams = versionArr[2].split('-');
            secondByte = versionParams[0];
            //last paramter should be less than 2pow6 (64)
            if(Number(versionArr[3]) >= 64) {
                throw Error('unsupported ppc3 version');
            }
            //set first two bits according to unstable version type
            switch (versionParams[1]) {
                case 'alpha': thirdByte_first2Bits = '01'; break;
                case 'beta': thirdByte_first2Bits = '10'; break;
                default:
                    throw Error('unsupported ppc3 version');
            }
            //convert last param to 6 bit val
            thirdByte_last6Bits = Number(versionArr[3]).toString(2);
            thirdByte_last6Bits = sixBitZeroes.slice(0, 6-thirdByte_last6Bits.length) + thirdByte_last6Bits;
        } else {
            throw Error('unsupported ppc3 version');
        }
        firstByte = toHexString(Number(versionArr[1]));
        secondByte = toHexString(Number(secondByte));
        thirdByte = toHexString(parseInt(thirdByte_first2Bits+thirdByte_last6Bits, 2));
        //return encoded version
        return firstByte + secondByte + thirdByte + RESERVED_BYTE;
    }

    // function convertCfgsToDSPMemory(configurations, devWriteCmds) {
    //     for(var index in configurations) {
    //         var configuration = configurations[index];
    //         for(var deviceName in devWriteCmds[configuration]) {
    //             if(deviceName.indexOf('COEFF') !== -1) {
    //                 var dspWriteData = self.convertWritesToDSPMemory(devWriteCmds[configuration][deviceName].data);
    //                 devWriteCmds[configuration][deviceName].data = dspWriteData;
    //             }
    //         }
    //     }
    // }

    this.convertWritesToDSPMemory = function(data) {
        var dspWrites = [];
        var data = data.slice();

        while(data.length > 0) {
            var write = data.shift();
            if(write.command) {
                // Specific commands
                switch(write.command) {
                    case "85" :
                        // This is a burst
                        var dspBurstWrites = convertBurstWritesToDSP(data, parseInt(write.param, 16))
                        dspWrites = dspWrites.concat(dspBurstWrites);
                        break;
                    case "81" :
                        // This is a delay
                        dspWrites.push(write);
                        break;
                }
            } else {
                // This is a simple write
                var dspMemory = convertToDSPMemory(parseInt(write.page, 16), parseInt(write.offset, 16));
                dspWrites.push(toWrite(
                    write.book,
                    dspMemory.dspPage,
                    dspMemory.dspOffset,
                    write.data)
                );
            }

        }
        return dspWrites;
    }

    function convertBurstWritesToDSP(data, length) {
        var burstWrite = data.shift();
        var hostPage = parseInt(burstWrite.page, 16);
        var hostOffset = parseInt(burstWrite.offset, 16);
        var dspWrites = [];
        var burstData;

        // We will first collect all writes and its target locations in allWrites array
        var allWrites = [];

        allWrites.push({
            location : convertToDSPMemory(hostPage, hostOffset),
            data : burstWrite.data
        });

        for(var i=1; i<length; i++) {
            var suffix = (i - 1) % 4;
            hostOffset++;

            if(suffix === 0) {
                burstData = data.shift();
            }

            allWrites.push({
                location : convertToDSPMemory(hostPage, hostOffset),
                data : burstData['data' + suffix]
            });
        }

        // Now we iterate through allWrites and identify the write commands
        // for DSP Memory
        var firstWrite = allWrites[0];
        var currentPage = firstWrite.location.dspPage;
        var currentBurst = [];
        var length = 1;
        var suffix;

        currentBurst.push(toWrite(
            burstWrite.book,
            firstWrite.location.dspPage,
            firstWrite.location.dspOffset,
            firstWrite.data
        ));

        for (var i=1; i<allWrites.length; i++) {
            if(currentPage === allWrites[i].location.dspPage) {
                // No change in page, continue with the burst.
                suffix = (length - 1) % 4;
                if(suffix === 0) {
                    burstData = {};
                    currentBurst.push(burstData);
                }
                burstData['data' + suffix] = allWrites[i].data;
                length++;
            } else {
                // There is a page switch in DSP memory while in the middle of Host Memory brust.

                // Complete the current burst and push it to dspWrites
                for(var j=suffix + 1; j<4; j++) {
                    burstData['data' + j] = '00';
                }
                currentBurst.unshift(burstBeginning(length));
                dspWrites = dspWrites.concat(currentBurst);

                // Initialize values again
                firstWrite = allWrites[i];
                currentPage = firstWrite.location.dspPage;
                currentBurst = [];
                length = 1;

                currentBurst.push(toWrite(
                    burstWrite.book,
                    firstWrite.location.dspPage,
                    firstWrite.location.dspOffset,
                    firstWrite.data
                ));
            }

        }
        // Complete the current burst and push it to dspWrites
        for(var j=suffix + 1; j<4; j++) {
            burstData['data' + j] = '00';
        }
        currentBurst.unshift(burstBeginning(length));
        dspWrites = dspWrites.concat(currentBurst);

        return dspWrites;
    }

    function burstBeginning(length) {
        // Pad to 4 byte size
        var lengthStr = ("0000" + length.toString(16)).slice(-4);

        return {
            param : lengthStr,
            command : "85",
            reserved : "00"
        }
    }
    function toWrite(book, page, offset, data) {
        var pageStr = ("00" + page.toString(16)).slice(-2);
        var offsetStr = ("00" + offset.toString(16)).slice(-2);
        return {
            book : book,
            page : pageStr,
            offset : offsetStr,
            data : data
        };
    }

    function convertToDSPMemory(hostPage, hostOffset) {
        // A location is 4 registers. 'position' indicates the
        // position of this hostOffset in the Host Memory location.
        //
        // We will remove position during calculation and then finally
        // add it to the dspOffset
        var position = hostOffset % 4;
        hostOffset -= position;
        var hostLocation = ((hostPage - 1) * 30) + ((hostOffset - 8) / 4);
        var dspLocation = hostLocation - 500;

        return {
            dspPage : Math.floor(dspLocation / 30) + 1,
            dspOffset : (((dspLocation % 30) * 4) + 8) + position
        };
    }

    function convertVersionToHex(firmVer) {
        var arr = firmVer.split('.');
        var newFirmVer = '';
        arr.forEach(function(elem) {
            newFirmVer += toHexString(Number(elem));
        });
        return newFirmVer;
    }

    function convertDspVersionToBinFormat(ver) {
        return convertVersionToHex(ver);
    }

    function convertDriverVersionToBinFormat(ver) {
        var driverFirmVer = RESERVED_BYTE + RESERVED_BYTE + convertVersionToHex(ver);
        return driverFirmVer;
    }

    function giveMeAllDevicesSelectedValue(data) {
        if(data.hasOwnProperty("allDevicesSelected")) {
            return increaseByteSizeUptoFour(binStructConfiguration.types.configuration.fields.allDevicesSelected.length, toHexString(data.allDevicesSelected));
        } else {
            return undefined;
        }
    }

    function giveMeDeviceOrientationValue(data) {
        if(data.hasOwnProperty("devicesOrientation")) {
            return increaseByteSizeUptoFour(binStructConfiguration.types.configuration.fields.devicesOrientation.length, toHexString(data.devicesOrientation));
        } else {
            return undefined;
        }
    }

    function getAudioProfilesData(sysIntegData, configurations, size){
        //getting details as formed in controller
        var configNames = configurations.map(function(config){
            if(config.snapshotName) // Tuning Mode
                return config.programName+'-'+config.configName+'-'+config.snapshotName;
            else //Rom Mode
                return config.programName+'-'+config.configName;
        });
        //getting the index data for all configs
        var fullset =[];
        var sizePerOrient = size/sysIntegData.devOrientation.length;
        sysIntegData.devOrientation.forEach(function(orientation){
            var audioModes= sysIntegData.endSystemAudioModes[orientation];
            var configIndices = audioModes.map(function(mode){
                return configNames.indexOf(mode.config);
            });
            for(var i=0; i<sizePerOrient; i++){
                if(i < configIndices.length && (orientation === sysIntegData.devOrientation[0] || sysIntegData.numberOfDevices === 4)){
                    if(configIndices[i] === -1){
                        //for not supported modes
                        configIndices[i] = toHexString(0xff);
                    } else {
                        configIndices[i] = toHexString(configIndices[i]);
                    }
                } else {
                    //for redundant spaces
                    configIndices[i] = toHexString(0xff);
                }
            }
            fullset = fullset.concat(configIndices);
        })
        return fullset;
    }

    this.createJso = function (devWriteCmds, headersConfig, binFormat, sysIntegData) {
        var mapConfigNames = {};
        //initialize the binDumpsJso object
        var binDumpsJso = {};
        var blocks = {}, images = {}, headers = {};
        var programs = [], configurations = [], sizeOfPrograms = [], sizeOfConfigs = [];
        var block, image;
        var device, completeBlockData;
        var deviceName, blockName, imageName;
        var cfgName, newCfgName, cfg;
        var noOfPrograms, noOfConfigurations;
        var noOfPlls, plls = [], pllNameArr = [];
        var configName, newConfigName, config;
        var validDevWriteBlocks = Object.keys(enumsBin['blockType']);
        //map cfg names as sequential in blocks
        var programNameArr = [], cfgNameArr = [];
        return updateBinConfig(binFormat, sysIntegData).then(function(){
        // update cfgNames and programNames
        Object.keys(devWriteCmds).forEach(function (config) {
            if(devWriteCmds[config].type === 'program') {
                programNameArr[devWriteCmds[config].pos] = config;
            } else if (devWriteCmds[config].type === 'configuration') {
                cfgNameArr[devWriteCmds[config].pos] = config;
            } else if (devWriteCmds[config].type === 'pll') {
                pllNameArr[devWriteCmds[config].pos] = config;
            }
        });

        // create map for cfgNames
        cfgNameArr.forEach(function (cfgName, id) {
            mapConfigNames[cfgName] = 'configuration_'+ id;
        });
        // create map for programs
        programNameArr.forEach(function (programName, id) {
            mapConfigNames[programName] = 'program_'+ id;
        });
        pllNameArr.forEach(function (pllName, id) {
            mapConfigNames[pllName] = 'pll_'+ id;
        });
        // convertCfgsToDSPMemory(cfgNameArr, devWriteCmds);

        //build blocks
        for (configName in devWriteCmds) {
            //init blocks with new names
            config = devWriteCmds[configName];
            newConfigName = mapConfigNames[configName];
            blocks[newConfigName] = {};
            //create fields for blocks
            for(deviceName in config) {
                device = config[deviceName];
                //create Blocks only for valid keys (valid blockTypes) with some content
                if(validDevWriteBlocks.indexOf(deviceName) !== -1 &&
                        config[deviceName].data.commands.length > 0) {
                    blocks[newConfigName][deviceName] = getCompleteBlocks(deviceName, device, sysIntegData);
                }
            }
        }
        // console.log('blocks: ', blocks);

        //build images
        for(configName in devWriteCmds) {
            newConfigName = mapConfigNames[configName];
            config = devWriteCmds[configName];
            //create name, description for image
            for (deviceName in config) {
                //create only for valid keys (valid blockTypes)
                if(validDevWriteBlocks.indexOf(deviceName) !== -1) {
                    images[newConfigName] = {
                        'name': giveMeProperName(config[deviceName]['name']),
                        'description': giveMeProperDescription(config[deviceName]['description'])
                    };
                    //name and description will be same for image, so copying once is enough
                    break;
                }
            }
        }
        //update block data
        for (blockName in blocks) {
            block = blocks[blockName];
            images[blockName]['blocks'] = [];
            //create fields for image
            for(deviceName in block) {
                var deviceBlock = block[deviceName];
                images[blockName]['blocks'].push(deviceBlock);
            }
            images[blockName]['noOfBlocks'] = increaseByteSizeUptoFour(binStructConfiguration.types.image.fields.noOfBlocks.length,
             toHexString(Object.keys(block).length));
        }
        // console.log('images: ', images);

        //build programs
        programNameArr.forEach(function (programName) {
            var newProgramName = mapConfigNames[programName];
            var program = {
                'name': giveMeProperName(programName),
                'description': giveMeProperDescription(programName +' program'),
                'application': toHexString(
                    devWriteCmds[programName].application ),
                // TODO: PDM I2S Mode is hardcoded as disabled for now
                'pdmI2sMode': increaseByteSizeUptoFour(binStructConfiguration.types.program.fields.pdmI2sMode.length,
                    toHexString(0)),
                'iSensePd': increaseByteSizeUptoFour(binStructConfiguration.types.program.fields.iSensePd.length,
                    toHexString(devWriteCmds[programName].iSensePd)),
                'vSensePd': increaseByteSizeUptoFour(binStructConfiguration.types.program.fields.vSensePd.length,
                    toHexString(devWriteCmds[programName].vSensePd)),
                // TODO: Power up with LDG is hardcoded for now.
                'powerupWithLDG': increaseByteSizeUptoFour(binStructConfiguration.types.program.fields.powerupWithLDG.length,
                    toHexString(0)),
                'data': images[newProgramName]
            };
            programs.push(program);
        });
        var sizeDefault = increaseByteSizeUptoFour(4, "0x00");
        sizeOfPrograms = new Array(binStructConfiguration.maxPrograms);
        for(var i=0;i<sizeOfPrograms.length;i++){
            sizeOfPrograms[i]=sizeDefault;
        } 
        noOfPrograms = increaseByteSizeUptoFour(binStructConfiguration.fields.noOfPrograms.length, toHexString(programs.length));
        // console.log('programs: ', programs);

        //build configurations
        cfgNameArr.forEach(function (cfgName) {
            newCfgName = mapConfigNames[cfgName];
            var programIndex = programNameArr.indexOf(devWriteCmds[cfgName].program);
            // var pllIndex = pllNameArr.indexOf(devWriteCmds[cfgName].pll);
            var clockSource = devWriteCmds[cfgName].clockSource === "BCLK"? 0 : 1;
            var clockFrequency = parseFloat(devWriteCmds[cfgName].clockFrequency) * 1e6;
            var cfg = {
                'name': giveMeProperName(cfgName),
                'description': giveMeProperDescription('Tuning Settings'),
                'devicesOrientation': giveMeDeviceOrientationValue(devWriteCmds[cfgName]),
                'devices': increaseByteSizeUptoFour(binStructConfiguration.types.configuration.fields.devices.length,
                    toHexString(devWriteCmds[cfgName].devices) ),
                'program': increaseByteSizeUptoFour(binStructConfiguration.types.configuration.fields.program.length, toHexString(programIndex)),
                'samplingRate': increaseByteSizeUptoFour(binStructConfiguration.types.configuration.fields.samplingRate.length, toHexString(devWriteCmds[cfgName].sampleRate)),
                // 'pll': toHexString(pllIndex),
                'clockSource': increaseByteSizeUptoFour(binStructConfiguration.types.configuration.fields.clockSource.length, toHexString(clockSource)),
                'clockFrequency': increaseByteSizeUptoFour(binStructConfiguration.types.configuration.fields.clockFrequency.length, toHexString(clockFrequency)),
                // TODO: SBCLK to FS ratio is set as auto for the time being
                'sbclkFsRatio': increaseByteSizeUptoFour(binStructConfiguration.types.configuration.fields.sbclkFsRatio.length, toHexString(devWriteCmds[cfgName].sbclkFsRatio)),
                'data': images[newCfgName],
                'cfgName': cfgName,
                'programName': devWriteCmds[cfgName].program,
                'configName': devWriteCmds[cfgName].configName,
                'snapshotName': devWriteCmds[cfgName].snapshotName
            };
            configurations.push(cfg);
        });
        sizeOfConfigs = new Array(binStructConfiguration.maxConfigurations);
        for(var i=0;i<sizeOfConfigs.length;i++){
            sizeOfConfigs[i]=sizeDefault;
        } 
        // console.log(configurations);
        noOfConfigurations = increaseByteSizeUptoFour(binStructConfiguration.fields.noOfConfigurations.length, toHexString(configurations.length));

        /*//build plls
        var pllCfg;
        pllNameArr.forEach(function (pllName, id) {
            plls[id] = {};
            pllCfg = devWriteCmds[pllName];
            for (deviceName in pllCfg) {
                //create only for valid blocks
                if(validDevWriteBlocks.indexOf(deviceName) !== -1) {
                    //add name,description
                    plls[id]['name'] =  giveMeProperName(pllCfg[deviceName].name);
                    plls[id]['description'] = giveMeProperDescription(pllCfg[deviceName].description);
                    device = pllCfg[deviceName];
                    plls[id]['block'] = getCompleteBlocks(deviceName, device);
                }
            }
        });
        noOfPlls = increaseByteSizeUptoFour(2, toHexString(pllNameArr.length));*/
        // console.log('plls: ', plls);

        // time will be in ms, convert it to secs
        var time = Math.round((new Date().getTime())/1000);
        //configure the headers
        var binDumps = {
            'name': giveMeProperName(headersConfig.ddcName),
            'timeStamp': increaseByteSizeUptoFour(4, toHexString(time)),
            'version': getEncodedVersion(headersConfig.version),
            'dspFirmwareVersion': convertDspVersionToBinFormat(headersConfig.dspFirmwareVersion),
            'driverFirmwareVersion': convertDriverVersionToBinFormat(binStructConfiguration.driverFirmwareVersion),
            'magicNumber': headersConfig.magicNumber,
            'description': giveMeProperDescription(headersConfig.description),
            'deviceFamily': increaseByteSizeUptoFour(
                binStructConfiguration.fields.deviceFamily.length,
                toHexString(
                    parseInt(enumsBin['deviceType'][headersConfig.deviceFamily], 16) )
                ),
            'device': increaseByteSizeUptoFour(
                binStructConfiguration.fields.device.length,
                toHexString(
                    parseInt(enumsBin['device'][headersConfig.device], 16) )
                )
        };
        //save jso
        binDumps['noOfPrograms'] = noOfPrograms;
        binDumps['sizeOfPrograms'] = sizeOfPrograms;
        binDumps['programs'] = programs;
        binDumps['noOfConfigurations'] = noOfConfigurations;
        binDumps['sizeOfConfigs'] =  sizeOfConfigs;
        binDumps['configurations'] = configurations;
        if(binStructConfiguration.fields.audioProfiles){
            binDumps['audioProfiles'] = getAudioProfilesData(sysIntegData, configurations, binStructConfiguration.fields.audioProfiles.length);
        }
        return {
            'binDumps': binDumps,
            'mapConfigNames': mapConfigNames
        };
        });
    };

    function createRevMap(obj) {
        var reversedObj = {}, newKey;
        var keys = Object.keys(obj);
        if(! (keys && keys.length)) {
            return {};
        }
        keys.forEach(function (key, id) {
            newKey = obj[key];
            reversedObj[newKey] = key;
        });
        return reversedObj;
    }

    var applicationConstMap = (function (applicationConst) {
        var constMap = createRevMap(applicationConst);
        for (var prop in constMap) {
            constMap[prop] =
                constMap[prop].split(" ").join("").toLowerCase();
        }
        return constMap;
    })(binConstants.application);

    function appendCfgBlocks(data, allBlocksList, revConfigNames) {
        data.configurations.forEach(function (cfg, id) {
            //add blocks for cfgs
            allBlocksList[revConfigNames[id]] = {
                'blocks': cfg.data.blocks
            };
        });
        return allBlocksList;
    }

    function appendProgramBlocks(data, allBlocksList) {
        data.programs.forEach(function (program, id) {
            // add program blocks
            allBlocksList['program_'+id] = {
                'blocks': program.data.blocks
            };
        });
        return allBlocksList;
    }

    function getEquvalentBlockName(elem, sysIntegData, id, oneBlock) {
        elem.blockType = {};
        if(sysIntegData.binaryFormat === 'kernel.org'){
            elem.blockType['blockType'] = KerenelblockTypeReverseMap[elem.data.blockType];
        }else{
            elem.blockType['blockType'] = blockTypeReverseMap[elem.data.blockType];
        }
    }

    function extractBlockTypesFromEnum(allBlocksList,sysIntegData ) {
        for(var blockName in allBlocksList) {
            var oneBlock = allBlocksList[blockName];
            oneBlock['blocks'].forEach(function(obj){
                getEquvalentBlockName(obj, sysIntegData);
            });
        }
        return allBlocksList;
    }

    function generateDelayCmd(i2c, cmdVal, cfgStr) {
        cfgStr += ('d '+ cmdVal + eol);
        return cfgStr;
    }

    function generateBurstCmd(hexStr, cfgStr) {
        cfgStr += ('> '+ hexStr + eol);
        return cfgStr;
    }

    function generateDevWriteCmd(i2c, offset, data, cfgStr) {
        cfgStr += ('w '+ i2c + ' ' + offset + ' ' + data + eol);
        return cfgStr;
    }

    function generateBookSwitch(i2c, book, cfgStr) {
        cfgStr += ('w '+ i2c + ' 7f ' + book + eol);
        return cfgStr;
    }

    function generatePageSwitch(i2c, page, cfgStr) {
        cfgStr += ('w '+ i2c + ' 00 ' + page + eol);
        return cfgStr;
    }

    function giveMeEquvalentCfg(block, i2c) {
        var i2cDec = parseInt(i2c, 16);
        i2c = i2cDec.toString(16);
        var commands = block.commands;
        var oldBook, oldPage;
        var cmdType, cmdVal;
        var burstLength, burstLengthVault;
        var burstModeOn = false;
        var cfgStr = '';
        function generateCompleteWriteCmd(book, page, offset, data) {
            //update book
            if(oldBook !== book) {
                //do a page switch
                cfgStr = generatePageSwitch(i2c, '00', cfgStr);
                //update the oldPage
                oldPage = '00';
                //do book switch
                cfgStr = generateBookSwitch(i2c, book, cfgStr);
                oldBook = book;
            }
            //update page if needed
            if(oldPage !== page) {
                cfgStr = generatePageSwitch(i2c, page, cfgStr);
                oldPage = page;
            }
            cfgStr = generateDevWriteCmd(i2c, offset, data, cfgStr);
        }

        //create cfg for cmds
        commands.forEach(function (cmd) {
            //if, no burst data to read make burstMode off
            if(!burstLength && burstModeOn) {
                burstModeOn = false;
            }
            //find the type of cmd
            //offset is delay / burst and has reserved byte, then it will be a cmd
            //also the burstMode should be off (if not then it will be a burst data - not cmd)
            if((parseInt(cmd.offset,16) === parseInt(regDumpHexStrConst.burst, 16)) && (parseInt(cmd.data, 16) === 0) && !burstModeOn) {
                cmdVal = cmd.book + cmd.page;
                //burst mode
                burstModeOn = true;
                burstLength = parseInt(cmdVal, 16);
                burstLengthVault = burstLength;
                // update the cmdVal - wil be 4 bytes, to be converted as hexStr
                cmdVal = toHexString(burstLength);
                //no need to write the burst cmd
            } else if ((parseInt(cmd.offset,16) === parseInt(regDumpHexStrConst.delay, 16)) && (parseInt(cmd.data, 16) === 0) && !burstModeOn) {
                cmdVal = cmd.book + cmd.page;
                cmdVal = toHexString(parseInt(cmdVal, 16));
                //delay mode
                cfgStr = generateDelayCmd(i2c, cmdVal, cfgStr);
            } else {
                if(burstModeOn) {
                    //writeContents as burst data
                    if(burstLength === burstLengthVault) {
                        //generate initial dev write cmd
                        //which is a normal dev write
                        generateCompleteWriteCmd(cmd.book, cmd.page, cmd.offset, cmd.data);
                        --burstLength;
                    } else {
                        var cmdsInArr = [cmd.book, cmd.page, cmd.offset, cmd.data];
                        while(burstLength && cmdsInArr.length) {
                            //generate burst data cmd
                            cfgStr = generateBurstCmd(cmdsInArr.shift(), cfgStr);
                            --burstLength;
                        }
                    }
                } else {
                    //read as write command
                    generateCompleteWriteCmd(cmd.book, cmd.page, cmd.offset, cmd.data);
                }
            }
        });
        return cfgStr;
    }

    function giveMeNewBlockName(blockName, siblings, blockType, someDetailsForCfgGen) {
        var isTas2555Mono = someDetailsForCfgGen.isTas2555Mono;
        var newBlockName = someDetailsForCfgGen.mapConfigNamesReversed[blockName];
        var newName, configType, sr, hf;

        var newBlockNameSplit = newBlockName.split('_');
        var blockNameArr = blockName.split('_');
        var type = blockNameArr[0], index = blockNameArr[1];

        switch (type) {
            case 'pll':
                hf = newBlockNameSplit[2];
                sr = newBlockNameSplit[3];
                hf = hf.split(' ').join('');
                sr = sr.split(' ').join('');
                newName = 'pll_' +index +'_' +hf +'_' +sr;
                if(!isTas2555Mono && !someDetailsForCfgGen.hasAuxDevice) {
                    newName += ('_'+blockType);
                }
                break;

            case 'program':
                newName = 'program_' +index +'_' +newBlockName;
                if(!isTas2555Mono) {
                    newName += ('_'+blockType);
                }
                break;

            case 'configuration':
                hf = newBlockNameSplit[1] +'_';
                sr = newBlockNameSplit[2];
                // get config type
                if(newBlockName.indexOf('FactoryCalibration_') !== -1) {
                    configType = '_calibration_'+hf+'Configuration_';
                    hf = '';
                    sr = newBlockNameSplit[3].split(' ').join('');
                } else if(newBlockName.toLowerCase().indexOf('calib') !== -1) {
                    configType = '_calibration_';
                    hf = hf.split(' ').join('');
                    sr = sr.split(' ').join('');
                } else {
                    configType = '_';
                    hf = hf.split(' ').join('');
                    sr = sr.split(' ').join('');
                }
                newName = 'configuration_' +index +configType +hf +sr;

                if(blockType) {
                    newName += ('_'+blockType);
                }
                break;
        }
        return newName;
    }

    function blockToScripts(allCfgStrs, blockHeaders, blockName, siblings,
        someDetailsForCfgGen) {

        return function (elem) {
            var deviceIndex, deviceLabel;
            var blockType = elem.blockType['blockType'];
            var noOfDevices = someDetailsForCfgGen.devices.length;
            var block;

            if (noOfDevices === 1  ||
                blockType.indexOf('DEV_A') !== -1 ||
                blockType.indexOf('DEV_B') !== -1 ||
                blockType.indexOf('DEV_C') !== -1 ||
                blockType.indexOf('DEV_D') !== -1 ||
                (someDetailsForCfgGen.hasAuxDevice && blockType.indexOf('PLL') !== -1) ||
                blockType === 'MAIN_ALL_DEVICES') {
                var newBlockName = giveMeNewBlockName(blockName, siblings, blockType, someDetailsForCfgGen);
                // MAIN_ALL_DEVICES block should use first device
                if(blockType === 'MAIN_ALL_DEVICES') {
                    deviceIndex = 0;
                } else {
                    deviceLabel = blockType.split("_")[1];
                    deviceIndex = deviceInfo.getDeviceIndexFromLabel(deviceLabel);
                    // deviceIndex = (blockType.indexOf('DEV_B') !== -1) ? 1 : 0;
                }
                var deviceName = someDetailsForCfgGen.devices[deviceIndex];
                var slave = parseInt(someDetailsForCfgGen.i2c[deviceName]);
                block = elem.data.setSlave(slave);

                allCfgStrs[newBlockName] = block.cfg();
                blockHeaders[newBlockName] = block.header(newBlockName);
            } else {
                for(deviceIndex=0; deviceIndex<noOfDevices; deviceIndex++) {
                    var newBlockName = giveMeNewBlockName(blockName, siblings, blockType, someDetailsForCfgGen);
                    var deviceName = someDetailsForCfgGen.devices[deviceIndex];
                    var slave = parseInt(someDetailsForCfgGen.i2c[deviceName]);
                    block = elem.data.setSlave(slave);

                    newBlockName += (deviceIndex === 0) ? '_DEV_A' : '_DEV_B';
                    allCfgStrs[newBlockName] = block.cfg();
                    blockHeaders[newBlockName] = block.header();
                }
            }
        };
    }

    function appendPllBlocks(data, allBlocksList) {
        //append plls
        data.pll.forEach(function (aPll, id) {
            allBlocksList['pll_'+id] = {
                'blocks': [aPll.block]
            };
        });
        return allBlocksList;
    }

    function makeCompatibleWithBinReadStruct(allBlocksList) {
        // update block type
        for(var config in allBlocksList) {
            // for all modules
            allBlocksList[config].blocks.forEach(function(block) {
                // for all blocks in modules
                var blockVal = block.blockType;
                block.blockType = { 'blockType': blockVal };
            });
        }

        return allBlocksList;
    }

    /*function generateEnableBroadcastCfgStr(cfgScripts) {
        var str = '';
        str += cfgScripts['enable_broadcast'][1];
        str += cfgScripts['page_switch'][0];
        return str;
    }

    function generateDisableBroadcastCfgStr(cfgScripts) {
        var str = '';
        str += cfgScripts['disable_broadcast'][0];
        str += cfgScripts['page_switch'][1];
        return str;
    }*/

    function getCommonProgramBlock(blocks) {
        var ret;
        for (var i = 0; i < blocks.length; i++) {
            if (blocks[i].blockType.blockType === 'MAIN_ALL_DEVICES') {
                ret = blocks[i];
                break;
            }
        }
        return ret;
    }

    function findApplication(configuration, data) {
        var programIndex = parseInt(configuration.program, 16);
        var applicConst = Number(data.programs[programIndex].application);
        return applicationConstMap[applicConst];
    }

    function getCfgBlocksFromBinCmds(configuration, cfgScripts, someDetailsForCfgGen, data) {
        var blockSequence = ['mute', 'program', 'pre', 'coeff','tdm',
            'powerup', 'echoref_off', 'postPowerUp', 'Unmute'];
        var cfgCmds = {
            switchingScript: {},
            combinedScript: {},
            blockSequence: blockSequence,
        };
        // var pllIndex = parseInt(configuration.pll, 16);
        var programIndex = parseInt(configuration.program, 16);
        var devicesSettings = parseInt(configuration.devices, 16);
        var bothDeviceConfigsSelectedValue = 3, skipThisPowerup;
        var i, devName, deviceIndex, blockType, deviceLabel;
        var deviceNames = {};
        var noOfDevices = someDetailsForCfgGen.devices.length;
        var applicConst = Number(data.programs[programIndex].application);
        var application = applicationConstMap[applicConst];
        // var powerupKey = 'powerup_' + application;
        var programSwitchBlock;
        // Broadcast mode not supported for TAS2557 DualMono
        var isBroadcastModeNotSupported = !someDetailsForCfgGen.hasAuxDevice;
        var tas2559Mute, tas2560Mute;
        /*var samplingRate = parseInt(configuration.samplingRate, 16),
            clockErrorDetectCfg = "clock_error_detect";
        if (samplingRate === 8000) {
            clockErrorDetectCfg = "clock_error_detect_8k";
        }*/

        // Skip Aux device if it is ROM modes
        // ( this is true for 96KHz ROM modes as well)
        var skipAuxDevice = someDetailsForCfgGen.hasAuxDevice &&
            (applicConst === 0 || applicConst === 1 ||
                applicConst === 3 || applicConst === 4);

        // construct dev names
        for(i=0; i<noOfDevices; i++) {
            deviceNames[i] = someDetailsForCfgGen.devices[i];
        }
        // init cfgCmds struct for devices
        for(i=0; i<noOfDevices; i++) {
            devName = deviceNames[i];
            cfgCmds.combinedScript[devName] = {};
            cfgCmds.switchingScript[devName] = {};

            blockSequence.forEach(function(prop) {
                cfgCmds.combinedScript[devName][prop] = '';
                cfgCmds.switchingScript[devName][prop] = '';
            });
        }

        function addComments(comment, blockName, mode) {
            if(mode === 'start') {
                // at beginning
                devName = deviceNames[0];
                cfgCmds.combinedScript[devName][blockName] = comment;
            } else {
                // at the end
                devName = deviceNames[noOfDevices-1];
                cfgCmds.combinedScript[devName][blockName] += comment;
            }
        }

        if (skipAuxDevice) {
            noOfDevices -= 1;
        }

        // Mute - Powerdown - Reset
        for(i=0; i<noOfDevices; i++) {
            devName = deviceNames[i];
            if(someDetailsForCfgGen.muteMode){
                cfgCmds.combinedScript[devName]['mute'] =
                cfgScripts[someDetailsForCfgGen.muteMode][i];
            } else{
                cfgCmds.combinedScript[devName]['mute'] =
                    cfgScripts['mute-powerdown-reset'][i];
            }
        }

        // TDM
        for(i=0; i<noOfDevices; i++) {
            devName = deviceNames[i];
            cfgCmds.combinedScript[devName]['tdm'] =
                cfgScripts['tdm'][i];
        }

        // TDM
        for(i=0; i<noOfDevices; i++) {
            devName = deviceNames[i];
            cfgCmds.combinedScript[devName]['tdm'] =
                cfgScripts['tdm-ring'][i];
        }

        // PLL
        /*addComments('# PLL begins'+eol, 'pll', 'start');
        for(i=0; i<noOfDevices; i++) {
            devName = deviceNames[i];
            var slave = parseInt(someDetailsForCfgGen.i2c[devName]);
            if(someDetailsForCfgGen.hasAuxDevice && i) {
                // do not generate PLL for TAS2559 DEVICE B
                continue;
            }
            cfgCmds.combinedScript[devName]['pll'] +=
                data.pll[pllIndex].block.data.setSlave(slave).cfg();
            /*Saving pll for switchingScript though we do jquery extend,
            * Because,
            * PLL might get removed for TAS2557 DualMono(see adding program below)
            * This will avoid PLL going empty in this scenario
            *
            cfgCmds.switchingScript[devName]['pll'] +=
                data.pll[pllIndex].block.data.setSlave(slave).cfg();
        }
        addComments('# PLL ends'+eol, 'pll', 'end');*/

        var blockId, block;
        // Program
        addComments('# Program begins'+eol, 'program', 'start');
        var programBlocks = data.programs[programIndex].data.blocks;
        var commonProgramBlock;
        if (isBroadcastModeNotSupported && (noOfDevices>1) ) {
            commonProgramBlock = getCommonProgramBlock(programBlocks);
        }
        for (blockId in programBlocks) {
            blockType = programBlocks[blockId].blockType.blockType;
            /*
            for TAS2557 DualMono, broadcast mode cannot be supported in CFG,
            setting broadcast bit will require some code to be run
            */
            if(blockType === 'MAIN_ALL_DEVICES' && isBroadcastModeNotSupported) {
                continue;
            }
            // for MAIN_ALL_DEVICES use first device.
            if(blockType === 'MAIN_ALL_DEVICES') {
                deviceIndex = 0;
                devName = deviceNames[deviceIndex];
                /*// add enable broadcast script
                cfgCmds.combinedScript[devName]['program'] +=
                    generateEnableBroadcastCfgStr(cfgScripts);*/
            } else {
                // deviceIndex = blockType === 'DEV_A_MAIN' ? 0 : 1;
                deviceLabel = blockType.split("_")[1];
                deviceIndex = deviceInfo.getDeviceIndexFromLabel(deviceLabel);
                devName = deviceNames[deviceIndex];
            }
            // move PLL to program - broadcast
            /*if(blockType === 'MAIN_ALL_DEVICES') {
                cfgCmds.combinedScript[devName]['program'] +=
                    cfgCmds.combinedScript[devName]['pll'];
                cfgCmds.combinedScript[devName]['program'] +=
                    ('# PLL ends'+eol+eol);
                // remove all PLL
                cfgCmds.combinedScript[deviceNames[0]]['pll'] = '';
                cfgCmds.combinedScript[deviceNames[1]]['pll'] = '';
            }*/
            // add MAIN_DEVICE_A/B program blocks
            var slave = parseInt(someDetailsForCfgGen.i2c[devName]);
            if(commonProgramBlock) {
                cfgCmds.combinedScript[devName].program +=
                    commonProgramBlock.data.setSlave(slave).cfg();
            }
            cfgCmds.combinedScript[devName]['program'] +=
                programBlocks[blockId].data.setSlave(slave).cfg();
            /*// add disable broadcast script
            if(blockType === 'MAIN_ALL_DEVICES') {
                cfgCmds.combinedScript[devName]['program'] +=
                    generateDisableBroadcastCfgStr(cfgScripts);
            }*/
        }
        addComments('# Program ends'+eol, 'program', 'end');

        // Download PRE block
        addComments('# PRE begins'+eol, 'pre', 'start');
        for (blockId in configuration.data.blocks) {
            block = configuration.data.blocks[blockId];
            blockType = block.blockType.blockType;
            if ((blockType.indexOf('PRE') !== -1)) {
                deviceLabel = blockType.split("_")[1];
                deviceIndex = deviceInfo.getDeviceIndexFromLabel(deviceLabel);
                devName = deviceNames[deviceIndex];
                var slave = parseInt(someDetailsForCfgGen.i2c[devName]);
                cfgCmds.combinedScript[devName]['pre'] +=
                    block.data.setSlave(slave).cfg();
            }
        }
        addComments('# PRE ends'+eol, 'pre', 'end');

        // Powerup
        /*for(i=0; i<noOfDevices; i++) {
            devName = deviceNames[i];
            skipThisPowerup = (noOfDevices > 1) &&
                (devicesSettings !== bothDeviceConfigsSelectedValue) &&
                (devicesSettings !== i+1);
            /* for TAS2559, device A powerup also should be present
            even when only device B is selected
            (device A powerup will be present always) *
            if (someDetailsForCfgGen.hasAuxDevice && i === 0) {
                skipThisPowerup = false ;
            }
            if(skipThisPowerup) {
                continue;
            }
            cfgCmds.combinedScript[devName]['powerup'] = cfgScripts[powerupKey][i];
        }*/

        // Configuration
        var configurationBlocks = configuration.data.blocks;
        addComments('# Configuration begins'+eol, 'coeff', 'start');

        // Download COEFF block
        for (blockId in configuration.data.blocks) {
            block = configuration.data.blocks[blockId];
            blockType = block.blockType.blockType;
            if (blockType.indexOf('COEFF') !== -1) {
                deviceLabel = blockType.split("_")[1];
                deviceIndex = deviceInfo.getDeviceIndexFromLabel(deviceLabel);
                devName = deviceNames[deviceIndex];
                var slave = parseInt(someDetailsForCfgGen.i2c[devName]);
                cfgCmds.combinedScript[devName]['coeff'] +=
                    block.data.setSlave(slave).cfg();
            }
        }
        addComments('# Configuration ends'+eol, 'coeff', 'end');

        // Unmute
        for(i=0; i<noOfDevices; i++) {
            devName = deviceNames[i];
            skipThisPowerup = (noOfDevices > 1) &&
                (devicesSettings !== bothDeviceConfigsSelectedValue) &&
                (devicesSettings !== i+1);
            if(skipThisPowerup) {
                continue;
            }
            cfgCmds.combinedScript[devName]['Unmute'] =
                cfgScripts['Unmute'][i];
        }

        // echoref_off
        // FIXME: update for TAS2563
        for(i=0; i<noOfDevices; i++) {
            if(!cfgScripts['echoref_off'] ||
                application.toLowerCase() !== "tuningmode") {
                continue;
            }
            devName = deviceNames[i];
            if(someDetailsForCfgGen.hasAuxDevice && i) {
                // donot generate SRTS for TAS2559 DEVICE B
                continue;
            }
            cfgCmds.combinedScript[devName]['echoref_off'] =
                cfgScripts['echoref_off'][i];
        }

        /*// clock_error_detect
        for(i=0; i<noOfDevices; i++) {
            devName = deviceNames[i];
            cfgCmds.combinedScript[devName]['clock_error_detect'] =
                cfgScripts[clockErrorDetectCfg][i];
        }*/

        /*// Download POST_POWER_UP block
        addComments('# PostPowerUp begins'+eol, 'postPowerUp', 'start');
        for (blockId in configuration.data.blocks) {
            block = configuration.data.blocks[blockId];
            if (block.blockType.blockType.indexOf('POST_POWER_UP') !== -1) {
                deviceIndex = block.blockType.blockType.indexOf('DEV_A') === -1 ? 1 : 0;
                devName = deviceNames[deviceIndex];
                var slave = parseInt(someDetailsForCfgGen.i2c[devName]);
                cfgCmds.combinedScript[deviceNames[deviceIndex]]['postPowerUp'] =
                    block.data.setSlave(slave).cfg();
            }
        }
        addComments('# PostPowerUp ends'+eol, 'postPowerUp', 'end');*/


        // create switchingScript from combined script
        cfgCmds.switchingScript =
            $.extend(true, cfgCmds.switchingScript, cfgCmds.combinedScript);

        /*In Switching script, change
        * mute-powerdown-reset -> powerdown
        * program -> optimized program (for TAS2559 only - Device A)
        */
        for (i = 0; i < noOfDevices; i++) {
            devName = deviceNames[i];

            cfgCmds.switchingScript[devName]['mute'] =
                cfgScripts['powerdown'][i];

            //do not update TAS2560 program
            if(someDetailsForCfgGen.hasAuxDevice && i) {
                continue;
            }

            if (application.indexOf('96khz') !== -1) {
                programSwitchBlock = 'program-switch-' +
                    application.split("96khz")[0];
            } else {
                programSwitchBlock = 'program-switch-' + application;
            }

            cfgCmds.switchingScript[devName]['program'] =
                cfgScripts[programSwitchBlock][i];
        }

        // add comments to program block
        if(cfgCmds.switchingScript[deviceNames[0]]['program']
            .indexOf("# Program begins") === -1) {

            cfgCmds.switchingScript[deviceNames[0]]['program'] =
                ("# Program begins" + eol) +
                cfgCmds.switchingScript[deviceNames[0]]['program'];
        }
        if(cfgCmds.switchingScript[deviceNames[noOfDevices-1]]['program']
            .indexOf("# Program ends") === -1) {

            cfgCmds.switchingScript[deviceNames[noOfDevices-1]]['program'] +=
                ("# Program ends" + eol);
        }

        /*
        * In TAS2559,
        * Since only TAS2559 has data, mute TAS2560 first & then TAS2559
         */
        if(someDetailsForCfgGen.hasAuxDevice) {
            // Add TAS2560 mute to ROM Mode
            if (application.indexOf('rommode') !== -1) {
                cfgCmds.combinedScript[deviceNames[1]].mute =
                    cfgScripts['mute-powerdown-reset'][1];
                cfgCmds.switchingScript[deviceNames[1]].mute =
                    cfgScripts['powerdown'][1];
            }

            // update combined script
            tas2559Mute = cfgCmds.combinedScript[deviceNames[0]].mute;
            tas2560Mute = cfgCmds.combinedScript[deviceNames[1]].mute;
            cfgCmds.combinedScript[deviceNames[0]].mute = tas2560Mute;
            cfgCmds.combinedScript[deviceNames[1]].mute = tas2559Mute;

            // update switching script
            tas2559Mute = cfgCmds.switchingScript[deviceNames[0]].mute;
            tas2560Mute = cfgCmds.switchingScript[deviceNames[1]].mute;
            cfgCmds.switchingScript[deviceNames[0]].mute = tas2560Mute;
            cfgCmds.switchingScript[deviceNames[1]].mute = tas2559Mute;
        }

        return cfgCmds;
    }

    function combineCfgBlocks(blocks, cfgCmds, devices) {
        return blocks.reduce(function(acc, block) {
            return devices.reduce(function(acc, deviceName) {
                return acc + (cfgCmds[deviceName][block] || '');
            }, acc);
        }, '');
    }

    function generateCombinedScriptFromBlocks(cfgCmds, someDetailsForCfgGen) {
        var devices = someDetailsForCfgGen.devices;
        var blockSequence = cfgCmds.blockSequence;
        var index = blockSequence.indexOf('tdm');
        var newBlockSequence;
        if(index != -1) {
            newBlockSequence = angular.copy(blockSequence);
            newBlockSequence.splice(index, 1);
        } else {
            newBlockSequence = blockSequence;
        }
        return combineCfgBlocks(newBlockSequence, cfgCmds.combinedScript, devices);
    }

    function generateCombinedScriptWithTDMFromBlocks(cfgCmds, someDetailsForCfgGen) {
        var devices = someDetailsForCfgGen.devices;
        var blockSequence = cfgCmds.blockSequence;        
        return combineCfgBlocks(blockSequence, cfgCmds.combinedScript, devices);
    }

    function generateSwitchingScript(cfgCmds, someDetailsForCfgGen) {
        var devices = someDetailsForCfgGen.devices;
        var blockSequence = cfgCmds.blockSequence;

        return combineCfgBlocks(blockSequence, cfgCmds.switchingScript, devices);
    }

    function getCfgHeaders(someDetailsForCfgGen) {
        var header = '';
        header += "#########################################################" +eol;
        header += ('# ' +someDetailsForCfgGen.appName +' debug cfg file' +eol);
        header += ('# PPC3 File: ' +someDetailsForCfgGen.ppc3File +eol);
        header += ('# ' +someDetailsForCfgGen.appName +' version: ' +
            someDetailsForCfgGen.appVersion +eol);
        header += ('# DDC Name: ' +someDetailsForCfgGen.ddcName +eol);
        header += ('# Binary Version: ' +binStructConfiguration.version +eol);
        header += "#########################################################" +eol;
        return header;
    }

    function generateCfgFiles(data, folderPaths, someDetailsForCfgGen, cfgScripts, sysIntegData) {
        //maintain all blocks as array (pll blocks will not be an array)
        var allBlocksList = {};
        var allCfgStrs = {}, cfgName;
        var blockHeaders = {}, headerName;
        var allFileWriteProms = [];
        var cfgCmds = {};
        var fileName, content;
        var blockName, aBlock, noOfBlocks;

        // update map
        someDetailsForCfgGen.mapConfigNamesReversed = createRevMap(someDetailsForCfgGen.mapConfigNames);
        var revConfigNames = Object.keys(someDetailsForCfgGen.mapConfigNamesReversed).filter(function (name) {
            return name.indexOf('configuration') !== -1;
        });

        //find all blocks and add it
        // allBlocksList = appendPllBlocks(data, allBlocksList);
        allBlocksList = appendProgramBlocks(data, allBlocksList);
        allBlocksList = appendCfgBlocks(data, allBlocksList, revConfigNames);

        // since srts data is not read from bin, make compatible with binary read data
        if(someDetailsForCfgGen.makeCmdsBinCompatible) {
            allBlocksList = makeCompatibleWithBinReadStruct(allBlocksList);
        }

        //extract blockType
        allBlocksList = extractBlockTypesFromEnum(allBlocksList, sysIntegData);

        /* TODO: Binary dump speed can be improved.
        * same cfgs are created repeatedly for,
        *  1) creating cfg for each block
        *  2) creating combined files
        *
        *  Also, SRTS cfgs generation and debug cfg generation can be optimized
        *  Currently both are created independently
        */

        //write allCfgStrs
        if(someDetailsForCfgGen.skipAllDebugCfgWrites &&
            someDetailsForCfgGen.skipHeaderFileGeneration) {

            // do not create cfg/header files
        } else {
            //create cfgs for all blocks
            for(blockName in allBlocksList) {
                aBlock = allBlocksList[blockName];
                noOfBlocks = aBlock['blocks'].length;
                aBlock['blocks'].forEach(
                    blockToScripts(allCfgStrs, blockHeaders, blockName,
                        noOfBlocks, someDetailsForCfgGen)
                );
            }

            if (!someDetailsForCfgGen.skipAllDebugCfgWrites) {
                for(cfgName in allCfgStrs) {
                    fileName = path.resolve(folderPaths.cfg + cfgName + '.cfg');
                    content = allCfgStrs[cfgName];
                    content = getCfgHeaders(someDetailsForCfgGen) + content;
                    allFileWriteProms.push(fileOps.writeToFile(fileName, content));
                }
            }

            if (!someDetailsForCfgGen.skipHeaderFileGeneration) {
                for(headerName in blockHeaders) {
                    fileName = path.resolve(folderPaths.h + headerName + '.h');
                    content = blockHeaders[headerName];
                    allFileWriteProms.push(fileOps.writeToFile(fileName, content));
                }
            }
        }

        var deviceIndex, deviceName;
        var cfgDebugData = {}, prom;
        // generate combined scripts
        data.configurations.forEach(function(configuration, id) {
            var blockName = revConfigNames[id];
            var combinedCfgStr, switchingScript, combinedCfgWithTDMStr;
            var combinedCfgName, switchingScriptName, combinedCfgWithTDMName;
            var application = findApplication(configuration, data);
            var pathToSave = folderPaths.cfg;

            // get blocks of combined scripts
            cfgCmds = getCfgBlocksFromBinCmds(configuration, cfgScripts, someDetailsForCfgGen, data);

            // get file name
            var filename =  giveMeNewBlockName(blockName, 0, undefined, someDetailsForCfgGen);
            combinedCfgName = 'combined_' + filename;
            switchingScriptName = 'switching_' + filename;

            if(someDetailsForCfgGen.srtsMode) {
                combinedCfgName += 'srts';
                switchingScriptName += 'srts';
                pathToSave = folderPaths.srts;
            }

            combinedCfgWithTDMName = path.resolve(pathToSave +combinedCfgName +'_withTDM.cfg');
            combinedCfgName = path.resolve(pathToSave +combinedCfgName +'.cfg');
            switchingScriptName = path.resolve(pathToSave +switchingScriptName +'.cfg');

            // write scripts
            if(someDetailsForCfgGen.writeCombinedScriptsToFile) {
                // generates combined scripts
                var headers = getCfgHeaders(someDetailsForCfgGen) ;
                combinedCfgStr = generateCombinedScriptFromBlocks(cfgCmds, someDetailsForCfgGen);
                combinedCfgStr = headers + combinedCfgStr;
                combinedCfgWithTDMStr = generateCombinedScriptWithTDMFromBlocks(cfgCmds, someDetailsForCfgGen);
                combinedCfgWithTDMStr = headers + combinedCfgWithTDMStr;
                allFileWriteProms.push(fileOps.writeToFile(combinedCfgName, combinedCfgStr));
                allFileWriteProms.push(fileOps.writeToFile(combinedCfgWithTDMName, combinedCfgWithTDMStr));


                // generate switching scripts

                // No switching script for TAS2563 yet
                // if(application !== "rammode") {
                //     switchingScript = generateSwitchingScript(cfgCmds,
                //         someDetailsForCfgGen);
                //     switchingScript =
                //         getCfgHeaders(someDetailsForCfgGen) + switchingScript;
                //     allFileWriteProms.push(
                //         fileOps.writeToFile(switchingScriptName, switchingScript)
                //     );
                // }
            }
            // cfgCmds for debug
            cfgDebugData[fileName] = cfgCmds;
        });
        // return cfgCmds
        return $q.when(allFileWriteProms).then(function () {
            return cfgDebugData;
        }).catch(function (err) {
            console.log("%cFailed to generate debug cfg files", "color:red");
            return $q.reject(err);
        });
    }

    function appendCfgWithSrtsCfg(cfgScripts) {
        var fp = path.join(DeviceManagerService.getPluginPath(), 'config/ddf/srts.cfg');
        var contents = fs.readFileSync(fp, 'utf8');
        cfgScripts['srts'] = contents;
        return cfgScripts;
    }

    function getScriptsForCombinedScripts(someDetailsForCfgGen) {

        var deferred = $q.defer();
        var reqCfgs = [
            'mute-powerdown-reset',
            'mute-powerdown',
            'powerdown',
            'page_switch',
            'program-switch-tuningmode',
            'program-switch-rommode',
            'program-switch-rommode1',
            'program-switch-rommode2',
            'Unmute',
            'tdm',
            'tdm-ring'
        ];
        if(someDetailsForCfgGen.srtsMode) {
            reqCfgs.push('echoref_off');
        }
        var cfgScripts = {};
        reqCfgs.forEach(function (fileName) {
            cfgScripts[fileName] = {};
        });
        var filePath, name, deviceIndex, deviceName, fileName;
        var isROMMode = Object.keys(someDetailsForCfgGen.mapConfigNames).indexOf('ROM Mode') > -1;
        loopAsync(someDetailsForCfgGen.devices.length, function (devLoop) {
            // get deviceIndex
            deviceIndex = devLoop.iteration();
            deviceName = someDetailsForCfgGen.devices[deviceIndex];
            var slave = parseInt(someDetailsForCfgGen.i2c[deviceName], 16);
            // dump all files
            loopAsync(reqCfgs.length, function (filesLoop) {
                // get the required ddf and reaunmute-device
                name = reqCfgs[filesLoop.iteration()];
                var reg02Operations = ['mute-powerdown-reset','mute-powerdown','Unmute', 'powerdown'];

                /* For Mute, Powerdown and Unmute use the DDF to mask the I and V sense values and update only mute field value in
                ROM mode. This is done to avoid overwriting the value of ISense and VSense as these fields are also present in the same 
                register as mute, powerdown field. In Tuning mode, I and V sense are always enabled. So just read the cfg files*/
                if(isROMMode && reg02Operations.indexOf(name) > -1){
                    var fileNames = {'mute-powerdown-reset':'mute-powerdown-reset.ddf',
                    'powerdown':'powerdown.ddf',
                    'mute-powerdown':'mute-powerdown.ddf',
                    'Unmute':'unmute.ddf'};
                    fileName = fileNames[name];
                    filePath = path.join(DeviceManagerService.getPluginPath(), 'config/ddf/' + fileName);
                    // continue if no cfg available
                    if(!fs.existsSync(filePath)) {
                        filesLoop.next();
                        return;
                    }
                    var ddfStr = fs.readFileSync(filePath, 'utf8');
                    if($injector.has('ddfDumpService')) {
                        var ddfDumpService = $injector.get('ddfDumpService');
                        var options = {
                            slave: slave,
                            device: deviceName
                        }
                        ddfDumpService.dumpDdf(ddfStr, options, binStructConfiguration.version).then(function(block){
                            var cfgStr = block.cfg(options);
                            cfgScripts[name][deviceIndex] = cfgStr;
                            filesLoop.next();                            
                        }, function(error){
                            deferred.reject(error);
                        })
                     }
                     else{
                         deferred.reject('Error in DDF');
                     }
                }
                else{
                    fileName = name;
                    /*
                    * for TAS2559,
                    * powerup, unmute and clock_error_detect scripts
                    * are different for each devices
                    *
                    if(someDetailsForCfgGen.hasAuxDevice && deviceIndex && (
                        (fileName.indexOf("mute-powerdown") !== -1) ||
                        (fileName.indexOf("powerup") !== -1) ||
                        (fileName.indexOf("clock_error_detect") !== -1) ||
                        (fileName.indexOf("unmute-device") !== -1)) ) {
                        fileName += "_2560";
                    }*/
                    filePath = path.join(DeviceManagerService.getPluginPath(), 'config/processflows/' + fileName +'.cfg');
                    // continue if no cfg available
                    if(!fs.existsSync(filePath)) {
                        filesLoop.next();
                        return;
                    }
                    var cfgStr = fs.readFileSync(filePath, 'utf8');
                    if(binStructConfiguration.version === 2){
                        cfgScripts[name][deviceIndex] = new Block_V2(cfgStr).cfg({slave : slave});
                    } else {
                        cfgScripts[name][deviceIndex] = new Block(cfgStr).cfg({slave : slave});
                    }
                    filesLoop.next();
                }
            }, function () {
                devLoop.next();
            });
        }, function () {
            deferred.resolve(cfgScripts);
        });
        return deferred.promise;
    }

    function writeCfgFromBinCmds(data, folderPaths, someDetailsForCfgGen, sysIntegData) {
        return getScriptsForCombinedScripts(someDetailsForCfgGen).then(function (cfgScripts) {
            return generateCfgFiles(data, folderPaths, someDetailsForCfgGen, cfgScripts, sysIntegData);
        });
    }

    this.generateCfgsFromJso = function (binDumps, folderPaths, someDetailsForCfgGen, sysIntegData) {
        return writeCfgFromBinCmds(binDumps, folderPaths, someDetailsForCfgGen, sysIntegData);
    };

    this.createBinFromDumps = function (binDumps, folderPaths, binFormat, sysIntegData) {
        //create binary file
        var binPath = path.resolve(folderPaths.bin + '.bin');
        return updateBinConfig(binFormat, sysIntegData).then(function () {
          //create binary file
          var binCreateObj = processBinary.createBinary(binStructConfiguration, binDumps, binFormat);
          if(binCreateObj.error) {
              return $q.reject(binCreateObj.error);
          }
        return fileOps.writeToFile(binPath, binCreateObj.value);
      });
    };

    this.generateDebugFilesForBin = function (folderPaths, someDetailsForCfgGen, sysIntegData) {
        var binPath = path.resolve(folderPaths.bin + '.bin');
        var jsonPath = path.resolve(folderPaths.bin + '.json');
        //create a json for binFile
        var constructJsoObj = processBinary.constructJsoFromBinary(binStructConfiguration, binPath);
        if(constructJsoObj.error) {
            return $q.reject(constructJsoObj.error);
        }
        var formattedJso = JSON.stringify(constructJsoObj.value, null, 4);
        return fileOps.writeToFile(jsonPath, formattedJso)
        .then(function () {
            //create cfgs and combined scritps
            return writeCfgFromBinCmds(constructJsoObj.value, folderPaths, someDetailsForCfgGen, sysIntegData);
        }).catch(function (err) {
            return $q.reject(err);
        });
    };

}]);
