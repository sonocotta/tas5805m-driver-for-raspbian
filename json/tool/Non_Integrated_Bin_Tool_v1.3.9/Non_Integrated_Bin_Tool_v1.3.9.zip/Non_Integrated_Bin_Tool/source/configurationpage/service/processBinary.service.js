mainApp.service('processBinary', ['Block', 'Block_V2', function(Block, Block_V2) {
    'use strict';
    /*global CRC32*/
    var fs = require('fs');
    var path = require('path');
    //flag that has permission for constructing binary
    var doNotCreateBin = false;
    //holds the Structure of binary file
    var binConfig;
    //binaryBuf holder (stores created buf from bin-dumps)
    var binWriteContainer;
    var startOfProgramSize;
    //to reconstruct bindumps
    var binParsedJso = {}, binBufReadFromFile, binBufPtr;
    var sizeOfPrograms = [], sizeOfConfigs = [];
    function throwError(errorMsg) {
        throw new Error(errorMsg);
    }
    
    function initBinContainer() {
        binWriteContainer = new Buffer(0);
        binBufPtr = 0;
        sizeOfConfigs = [], sizeOfPrograms = [];
        startOfProgramSize = binConfig["startOfProgramSize"];
    }
    
    function initBinParsedJso() {
        binParsedJso = {};
        binParsedJso.maxConfigurations = toHexString(binConfig.maxConfigurations);
        binParsedJso.maxPrograms = toHexString(binConfig.maxPrograms);
    }
    
    function setBinData(buf) {
        binBufReadFromFile = buf;
    }
    
    function toHexString(num) {
        var hexString = num.toString(16);
        if(num < 16) {
            return "0" + hexString;
        }
        return hexString;
    }
    
    // NOTE - a copy of this func will be in binaryDump.service, if you do any changes do it there as well
    function increaseByteSizeUptoFour(bytesTo, hexValStr) {
        //make sure hexValStr is proper - do not remove this
        hexValStr = toHexString(parseInt(hexValStr, 16));
        //increase the size
        var concatenatedStr = "00000000" + hexValStr;
        var finalStr = concatenatedStr.slice(-2*bytesTo);
        return finalStr;
    }
    
    function checkDataOnMandatory(config, fieldName, value) {
        if(!config.mandatory) {
            return;
        } else {
            if(!value) {
                throwError('field '+ fieldName +'missing from binary dump object');
            }
        }
    }
    
    function isValString(val) {
        if('string' !== typeof val) {
            throwError('failed to match expected type, type expected: '+' string '+ ', value type: '+typeof val);
        }
    }
    
    function isValInteger(val) {
        if( !(typeof val === 'number' && val%1 ===0) ) {
            throwError('failed to match the type. '+val+' is not a integer');
        }
    }
    
    function isOfStandardTypes(type, val) {
        switch (type) {
            case "int":
                //some fields will be hex strings, not numbers
                if(typeof val === 'number') {
                    isValInteger(val);
                } else if (typeof val === 'string') {
                    isValInteger(parseInt(val, 16));
                } else {
                    throwError('invalid type, type:'+ type);
                }
                break;
            case "string":
                isValString(val);
                break;
        }
        return type;
    }
    
    function isOfExpectedLength(lengthExpected, type, val) {
        //length will be in bytes for buffer length
        //int will be of hex str (two char each will be one byte)
        var valLength = val.length;
        if(type === 'int') {
            valLength = (val.length/2);
        }
        if(lengthExpected !== valLength) {
            throwError('unexpected length, val:'+val+', length expected:'+lengthExpected+', actual length:'+valLength);
        }
    }
    
    function isValOfEnum(listOfVal, valToCompare) {
        //enums values will be hexstr, so convert to decimal and validate
        var allVal = [];
        for(var key in listOfVal) {
            allVal.push(parseInt(listOfVal[key], 16));
        }
        //convert valToCompare to hex
        valToCompare = parseInt(valToCompare, 16);
        //thow eror if not matching any one of enums
        if(allVal.indexOf(valToCompare) === -1) {
            throwError('mismatch in enums, could not find value ',valToCompare);
        }
        return;
    }
    
    function getFieldsListInArray(fields) {
        var array = [];
        for(var fieldName in fields) {
            array.push(fieldName);
        }
        return array;
    }
    
    function processFields(field, fieldName, jsoVal) {
        var config;
        //a cutsom_object may have fields -> OR <- may not have..
        config = binConfig['types'][fieldName];
        if(config.hasOwnProperty('fields')) {
            config = config['fields'][field];
        }
        //  |||ar to objects, jsonVal also may/may not have values
        if(typeof jsoVal === 'object' && jsoVal.hasOwnProperty(field)) {
            jsoVal = jsoVal[field];
        }
        //validate/createBin
        processFieldData(config, jsoVal);
    }
    
    function compareTwoPrimitiveArr(arr1, arr2) {
        var arraysAreSame = true;
        if(!(Array.isArray(arr1) && Array.isArray(arr2))) {
            return false;
        }
        if(arr1.length !== arr2.length) {
            return false;
        }
        function shouldMatchWithArr2() {
            return function (elem, id) {
                if(elem !== arr2[id]) {
                    arraysAreSame = false;
                    return false;
                }
                return true;
            };
        }
        arr1.every(shouldMatchWithArr2());
        return arraysAreSame;
    }
    
    function processCustomTypes(config, jsoVal) {
        var type = config.type;
        var fieldConfig, arrayOfFields, startLength, endLength;
        var possibleTypes, validType;
        switch(type) {
            case 'array':
                var newType = config['of'];

                if (newType === 'block') {
                    if(!doNotCreateBin) {
                        jsoVal.forEach(function (jsoFieldValue) {
                            var binary = jsoFieldValue.data.binary(binConfig.binaryFormatVersion);
                            createAndAddToBinaryContainer('suffix', binary);
                        });
                    }
                } else {
                    fieldConfig = binConfig['types'][newType];
                    //a type may or may not have fields
                    if(fieldConfig.hasOwnProperty('fields')) {
                        fieldConfig = fieldConfig['fields'];
                        arrayOfFields = getFieldsListInArray(fieldConfig);
                    } else {
                        arrayOfFields = [newType];
                    }
                    //validate/createBin for all elements
                    jsoVal.forEach(function (elem) {
                        startLength = binWriteContainer.length;
                        //validate/createBin for  all in fields
                        arrayOfFields.forEach(function (field) {
                            processFields(field, newType, elem);
                        });
                        endLength = binWriteContainer.length;
                        if(newType === 'program'){
                            sizeOfPrograms.push(endLength-startLength);
                        }
                        if(newType === 'configuration'){
                            sizeOfConfigs.push(endLength-startLength);
                        }
                    });
                }
                break;
                
            case 'union':
                //find the valid type
                possibleTypes = config['of'];
                var fieldsOfJsoVal = Object.keys(jsoVal);
                validType = undefined;
                var fieldsArrOfUnionElem, fieldsConfigOfUnionElem;
                //pick the first matching element by comparing the fields
                possibleTypes.some(function (type, index) {
                    fieldsConfigOfUnionElem = binConfig['types'][type];
                    //a type may or may not have fields
                    if(fieldsConfigOfUnionElem.hasOwnProperty('fields')) {
                        fieldsConfigOfUnionElem = fieldsConfigOfUnionElem['fields'];
                        fieldsArrOfUnionElem = getFieldsListInArray(fieldsConfigOfUnionElem);
                    } else {
                        fieldsArrOfUnionElem = [type];
                    }
                    if(compareTwoPrimitiveArr(fieldsArrOfUnionElem, fieldsOfJsoVal)) {
                        validType = type;
                        return true;
                    }
                });
                //type should be valid, if none matches then call for an error
                if(!validType) {
                    throwError('validating union failed, binDumps value: '+ jsoVal+' union config: '+JSON.stringify(config));
                }
                //continue constructing binary
                fieldConfig = binConfig['types'][validType];
                //a type may or may not have fields
                if(fieldConfig.hasOwnProperty('fields')) {
                    fieldConfig = fieldConfig['fields'];
                    arrayOfFields = getFieldsListInArray(fieldConfig);
                } else {
                    arrayOfFields = [validType];
                }
                //validate all in fields
                arrayOfFields.forEach(function (field) {
                        processFields(field, validType, jsoVal);
                });
                break;
                
            default:
                fieldConfig = binConfig['types'][type];
                //a type may or may not have fields
                if(fieldConfig.hasOwnProperty('fields')) {
                    fieldConfig = fieldConfig['fields'];
                    arrayOfFields = getFieldsListInArray(fieldConfig);
                } else {
                    arrayOfFields = [type];
                }
                //validate all in fields
                arrayOfFields.forEach(function (field) {
                    processFields(field, type, jsoVal);
                });
                break;
        }
    }
    
    function createAndAddToBinaryContainer(mode, data, encoding) {
        var newBuf;
        if(encoding) {
            newBuf = new Buffer(data, encoding);
        } else {
            newBuf = new Buffer(data);
        }
        switch (mode) {
            case 'prefix':
                binWriteContainer = Buffer.concat([newBuf, binWriteContainer]);
                break;
            case 'suffix':
                binWriteContainer = Buffer.concat([binWriteContainer, newBuf]);
                break;
            default:
                throwError('unexpected mode while adding buffer');
        }
    }
    
    function processFieldData(config, jsoFieldValue) {
        console.log(config);
        var expectedType = config.type;
        var values, type, encoding;
        //both validation and constut mode are handled
        switch (expectedType) {
            case 'int':
                type = isOfStandardTypes(expectedType, jsoFieldValue);
                if(config.length) {
                    isOfExpectedLength(config.length, type, jsoFieldValue);
                }
                if(!doNotCreateBin) {
                    createAndAddToBinaryContainer('suffix', jsoFieldValue, 'hex');
                }
                break;
            case 'string':
                type = isOfStandardTypes(expectedType, jsoFieldValue);
                if(config.length) {
                    isOfExpectedLength(config.length, type, jsoFieldValue);
                }
                if(!doNotCreateBin) {
                    createAndAddToBinaryContainer('suffix', jsoFieldValue);
                }
                break;
            case 'enum':
                //check the value is any one of enums
                values = config.values;
                isValOfEnum(values, jsoFieldValue);
                //if length specified, validate the length also
                if(config.length) {
                    isOfExpectedLength(config.length, config.valueType, jsoFieldValue);
                }
                if(!doNotCreateBin) {
                    if(config.valueType === 'int') {
                        encoding = 'hex';
                    }
                    createAndAddToBinaryContainer('suffix', jsoFieldValue, encoding);
                }
                break;
            case 'block':
                if(!doNotCreateBin) {
                    var binary = jsoFieldValue.data.binary(binConfig.binaryFormatVersion);
                    createAndAddToBinaryContainer('suffix', binary);
                }
                break;
            case 'program':
            case 'configuration':
            case 'pll':
            case 'image':
            case 'command':
            case 'array':
            case 'deviceType':
            case 'device':
            case 'commandType':
            case 'blockType':
            case 'write':
            case 'specificCommand':
            case 'genericCommand':
            case 'union':
                processCustomTypes(config, jsoFieldValue);
                break;
            default:
                throwError('invalid type specified on validation,type: '+ expectedType);
        }
    }
    
    function processFieldsOfJso(arrayOfFields, jsoFieldValue) {
        var fieldValue;
        //validate mandatory fields and their types for given fields
        arrayOfFields.forEach(function (fieldName) {
            fieldValue = jsoFieldValue[fieldName];
            //mandatory fields
            checkDataOnMandatory(binConfig['fields'][fieldName], fieldName,  fieldValue);
            //data type should match
            processFieldData(binConfig['fields'][fieldName], fieldValue);
        });
    }
    
    function excludeAllElements(src, toExclude) {
        //remove elements
        toExclude.forEach(function (elem, id) {
            var pos = src.indexOf(elem);
            if(pos !== -1) {
                src.splice(pos, 1);
            } else {
                console.error('field '+ elem +'does not exist to remove');
            }
        });
        return src;
    }
    
    function validateAndConstructBin(binDumpsJso) {
        try {
            var binCfgFields = binConfig.fields;
            //get list of fields to validate
            var fieldsToValidate = getFieldsListInArray(binCfgFields);
            var excludeList = ['magicNumber', 'checksum', 'size'];
            //remove exclude list from fieldsToValidate
            fieldsToValidate = excludeAllElements(fieldsToValidate, excludeList);
            //validate mandatory fields and their types
            processFieldsOfJso(fieldsToValidate,  binDumpsJso);
        } catch (e) {
            console.error(e);
            return { error: e };
        }
    }
    
    function fitStrTolen(str, maxLen) {
        //truncate str to maxLen
        str = str.slice(0, maxLen);
        //append null if req
        while(str.length < maxLen) {
            str += '\0';
        }
        return str;
    }
    
    function getEquavalentBin(str, encoding) {
        return (new Buffer(str, encoding));
    }
    
    function fitCrcToFourBytesHexStr(num) {
        var arr = new ArrayBuffer(4);
        var view = new DataView(arr);
        view.setInt32(0, num, false);
        var newCrcBinStr = '', eightBitStr;
        var i = 0;
        while (i < 4) {
            eightBitStr = ("00000000"+view.getUint8(i).toString(2)).slice(-8);
            newCrcBinStr += eightBitStr;
            ++i;
        }
        var decVal = parseInt(newCrcBinStr, 2);
        return  increaseByteSizeUptoFour(4, toHexString(decVal));
    }
    
    function generateCheckSumAndSize(binDumpsJso) {
        var newObj =  {
            checksum: undefined,
            size: undefined
        };
        //add crc as '0000', add magicNumber, add size to get a crc
        //size should be of complete size
        var tempFieldsToWrite = {
            'size': binWriteContainer.length + binConfig['fields']['size'].length + binConfig['fields']['checksum'].length +  binConfig['fields']['magicNumber'].length,
            'checksum': '00000000',
            'magicNumber': binDumpsJso['magicNumber']
        };
        tempFieldsToWrite.size = increaseByteSizeUptoFour(4, toHexString(tempFieldsToWrite.size));
        //create a temp buffer
        var tempBuffer;
        //add checksum
        tempBuffer = Buffer.concat([getEquavalentBin(tempFieldsToWrite['checksum'], 'hex'), binWriteContainer]);
        //add size
        tempBuffer = Buffer.concat([getEquavalentBin(tempFieldsToWrite['size'], 'hex'), tempBuffer]);
        //add magicNumber
        tempBuffer = Buffer.concat([getEquavalentBin(tempFieldsToWrite['magicNumber'], 'hex'), tempBuffer]);
        //find crc
        var crc = CRC32.buf(tempBuffer);
        //change it to hex string of 4 bytes
        crc = fitCrcToFourBytesHexStr(crc);
        //get size as hexStr
        var size = increaseByteSizeUptoFour(4, tempFieldsToWrite.size);
        
        newObj['checksum'] = crc;
        newObj['size'] = size;
        
        return newObj;
    }
    
    function sortFieldsByOrder(fields) {
        var arr = [];
        for(var fieldName in fields) {
            var index = fields[fieldName].position;
            arr[index] = fieldName;
        }
        return arr;
    }
    
    // function constructBin(fieldsToWrite, binDumpsJso) {
    //     var field;
    //     //construct bin for each fields
    //     fieldsToWrite.forEach(function (fieldName) {
    //         field = binDumpsJso[fieldName];
    //         //create Binary
    //         processData(binConfig['fields'][fieldName], field);
    //     });
    // }
    
    // function constructBinContentFromDumps(binDumpsJso) {
    //     //getFieldsToWrite
    //     var fieldsToWrite = sortFieldsByOrder(binConfig.fields);
    //     //exclude some items from fieldsToWrite
    //     var excludeList = ['magicNumber','checksum', 'size'];
    //     fieldsToWrite = excludeAllElements(fieldsToWrite, excludeList);
    //     //create Binary Content
    //     constructBin(fieldsToWrite, binDumpsJso);
    // }
        
    function createCompleteBinStruct(binDumpsJso) {
        try {
            var fieldsToWrite = ['checksum', 'size', 'magicNumber'];
            //add checksum and Size
            var partialBinHeadJso = generateCheckSumAndSize(binDumpsJso);
            partialBinHeadJso['magicNumber'] = binDumpsJso['magicNumber'];
            //not construct bin file 
            doNotCreateBin = true;
            //do validation alone
            fieldsToWrite.forEach(function (fieldName) {
                var field = partialBinHeadJso[fieldName];
                processFieldData(binConfig['fields'][fieldName], field);
            });
            //write all
            doNotCreateBin = false;
            fieldsToWrite.forEach(function (fieldName) {
                var encoding;
                if(binConfig['fields'][fieldName]['type'] === 'int') {
                    encoding = 'hex';
                }
                createAndAddToBinaryContainer('prefix', partialBinHeadJso[fieldName], encoding);
            });
        } catch (e) {
           return {
               error: e
           };
       }
    }
        var replaceSizeValues = function(){
        var buf1, totalProgramSize = 0;
        sizeOfPrograms.forEach(function(size, index){
            totalProgramSize += size;
            buf1 = getEquavalentBin(increaseByteSizeUptoFour(4, toHexString(size)), 'hex');
            buf1.copy(binWriteContainer, startOfProgramSize+ index*4, 0, 4);
        });
        var startOfConfigSize = startOfProgramSize + 4*binConfig.maxPrograms + 4;
        sizeOfConfigs.forEach(function(size, index){
            buf1 = getEquavalentBin(increaseByteSizeUptoFour(4, toHexString(size)), 'hex');
            buf1.copy(binWriteContainer, startOfConfigSize+ index*4, 0, 4);
        });
    }
    this.createBinary = function (binStructConfig, binDumpsJso, binFormat) {
        console.log('binDumps', binDumpsJso);
        //update the configuration
        binConfig = binStructConfig;
        //initialize binWriteContainer
        initBinContainer();
        //validate and create binary
        var errHolder = validateAndConstructBin(binDumpsJso);
        //reject if err
        if(errHolder && errHolder.error) {
            console.log("%c"+'oops :(, Error on validating binDumpsJso, '+errHolder.error, "color: red");
            return {
                'error': new Error('BinDumps Validation Failed')
            };
        }
        //create a complete Binary Structure
        errHolder = createCompleteBinStruct(binDumpsJso);
        //reject if err
        if(errHolder && errHolder.error) {
            console.log("%c"+'oops :(, Error on constructing binary Content, '+errHolder.error, "color: red");
            return {
                'error': new Error('Could not create Complete binary buffer')
            };
        }
        if(binFormat === 2){
            replaceSizeValues();
        }
        return {
            'value' :binWriteContainer
        };
    };
        function readBlockFromBuf_v2() {
        var blockType = parseInt(readIntFromBuf(4), 16);
        var checksum = parseInt(readIntFromBuf(4), 16);
        var length = parseInt(readIntFromBuf(4), 16);
        var end =  binBufReadFromFile.length;
        var content = binBufReadFromFile.slice(binBufPtr, end).toJSON().data;
        var block = Block_V2.fromBinary(content, blockType, checksum);
        length = block.len;
        var end = binBufPtr + length;
        binBufReadFromFile.slice(binBufPtr, end);
        binBufPtr = end;
        return block.dta;
    }

    function readBlockFromBuf_v2() {
        var blockType = parseInt(readIntFromBuf(4), 16);
        var checksum = parseInt(readIntFromBuf(4), 16);
        var length = parseInt(readIntFromBuf(4), 16);
        var end =  binBufReadFromFile.length;
        var content = binBufReadFromFile.slice(binBufPtr, end).toJSON().data;
        var block = Block_V2.fromBinary(content, blockType, checksum);
        length = block.len;
        var end = binBufPtr + length;
        binBufReadFromFile.slice(binBufPtr, end);
        binBufPtr = end;
        return block.dta;
    }

    function readBlockFromBuf(len) {
        var blockType = parseInt(readIntFromBuf(4), 16);
        var checksum = parseInt(readIntFromBuf(4), 16);
        var length = parseInt(readIntFromBuf(4), 16);
        var end = binBufPtr + (length * 4);
        var content = binBufReadFromFile.slice(binBufPtr, end).toJSON().data;
        binBufPtr = end;

        return Block.fromBinary(content, blockType, checksum);
    }
    
    function readIntFromBuf(len) {
        var end = binBufPtr + len;
        if(!len) {
            throwError('not a valid length to read');
        }
        // use 'hex' to read binary hex encoded values and convert to utf8 format hex values
        var data = binBufReadFromFile.toString('hex', binBufPtr, end);
        //update ptr pos
        binBufPtr = end;
        return data;
    }

    function readStrFromBuf(len) {
        var end, data;
        if(!len){
            //get the len of str (iterate until you find a null char '00')
            var i = 0;
            //condition is to avoid dead locks
            while (binBufReadFromFile.length > (binBufPtr+i)) {
                var elem = binBufReadFromFile.toString('', binBufPtr+i, binBufPtr+i+1);
                if(elem === '\0') {
                    len = i+1; //till null char
                    break;
                }
                ++i;
            }
        }
        end = binBufPtr + len;
        data = binBufReadFromFile.toString('', binBufPtr, end);
        binBufPtr = end;
        //truncate excess null chars if present in end
        if(data.indexOf('\0') !== -1) {
            data = data.substring(0, data.indexOf('\0'));
        }
        return data;
    }
    
    function readSecondaryFields(binJso, config) {
        var type = config.type;
        var fieldsToRead = [];
        
        //if type is union find the  type to read
        if(type === 'union') {
            type = config['of'][0];
        }
        
        config = binConfig['types'][type];
        //config may/may not have list of fields(nested)
        if(config.fields) {
            config = config.fields;
            fieldsToRead = sortFieldsByOrder(config);
        }
        if(fieldsToRead && fieldsToRead.length) {
            //read for each field
            fieldsToRead.forEach(function (fieldName) {
                readBinDataAsType(binJso, config[fieldName], fieldName);
            });
        } else {
            readBinDataAsType(binJso, config, type);
        }
    }
    
    function readArrOfSecondaryFields(binJso, config, iterations) {
        var newType;
        var fieldsToRead = [];
        //read fields of secondary field and update in config
        newType = config['of'];
        config = binConfig['types'][newType];
        //config may/may not have list of fields(nested)
        if(config && config.fields) {
            config = config.fields;
            fieldsToRead = sortFieldsByOrder(config);
        }
        for (var i = 0; i < iterations; i++) {
            if(fieldsToRead && fieldsToRead.length) {
                binJso[i] = {};
                //read for each field
                fieldsToRead.forEach(function (fieldName) {
                    readBinDataAsType(binJso[i], config[fieldName], fieldName);
                });
            } else {
                readBinDataAsType(binJso, config, i);
            }
        }
    }
    
    function getIterCountKey(str) {
        //should follow camelCase struct
        var firstChar = str.slice(0,1);
        str = str.substr(1);
        firstChar = firstChar.toUpperCase();
        //grammar - if not ends with 's' add it
        if(str.charAt(str.length-1) !== 's') {
            str += 's';
        }
        //should prefixed with 'noOf'
        return ('noOf' + firstChar + str);
    }
    
    function readBinDataAsType(binJso, config, fieldName) {
        var type = config.type;
        switch (type) {
            case 'int':
                binJso[fieldName] = readIntFromBuf(config.length);
                break;
            case 'string':
                //length may be undefined - so,
                //read till specified length (or) till you reach null char
                binJso[fieldName] = readStrFromBuf(config.length);
                break;
            case 'enum':
                if(config.valueType === 'int') {
                    binJso[fieldName] = readIntFromBuf(config.length);
                } else if(config.valueType === 'string') {
                    //if val is undefined, let read till null char
                    binJso[fieldName] = readIntFromBuf(config.length);
                } else {
                    throwError('unsupported value type while reading '+ fieldName +'(enum): '+ config.valueType);
                }
                break;
            case 'block':
                if(binConfig.version === 2){
                binJso[fieldName] = { data: readBlockFromBuf_v2() };
                } else {
                binJso[fieldName] = { data: readBlockFromBuf() };
                }
                break;
            case 'program':
            case 'configuration':
            case 'pll':
            case 'image':
            case 'command':
            case 'deviceType':
            case 'device':
            case 'commandType':
            case 'blockType':
            case 'write':
            case 'specificCommand':
            case 'genericCommand':
            case 'union':
                binJso[fieldName] = {};
                readSecondaryFields(binJso[fieldName], config);
                break;
            case 'array':
                binJso[fieldName] = [];
                var noOfIters;
                if(binConfig.version === 2){
                    noOfIters = binJso[config["size"]];
                    } else {
                    noOfIters = binJso[getIterCountKey(fieldName)];
                    }
                readArrOfSecondaryFields(binJso[fieldName], config, parseInt(noOfIters, 16));
                break;
            default:
                throwError('type '+type+' not supported to parse Binary');
        }
    }
    
    function readBinaryFields(pathOfBinFile) {
        try {
            //save the buffer to privare var
            var buf = fs.readFileSync(pathOfBinFile);
            //update a buffer
            setBinData(buf);
            //read the fields in order
            var fieldsToRead = sortFieldsByOrder(binConfig.fields);
            //this is primary fields of bin Structure
            var field;
            fieldsToRead.forEach(function (fieldName) {
                //create space to store fieldValue and get config
                field = binConfig['fields'][fieldName];
                //read each fields
                readBinDataAsType(binParsedJso, field, fieldName);
            });
            return binParsedJso;
        } catch (e) {
            return {error: e};
        }
    }
    
    this.constructJsoFromBinary = function (binStructConfig, pathOfBinFile) {
        //update the binConfig
        binConfig = binStructConfig;
        //init binParsedJso
        initBinParsedJso();
        //constructJsoFromBinary
        var data =  readBinaryFields(pathOfBinFile);
        //return data / error based on data read
        if(data) {
            if(data.error) {
                console.log("%c"+"parsing binary failed, "+data.error, "color: red");
                return {
                    'error': new Error('Failed to parse the binary Content')
                };
            } else {
                console.log('dataRead: ', data);
                return {
                    'value': data
                };
            }
        } else {
            return {
                'error': 'internal error occurred while parsing binary Content'
            };
        }
    };
    
}]);
