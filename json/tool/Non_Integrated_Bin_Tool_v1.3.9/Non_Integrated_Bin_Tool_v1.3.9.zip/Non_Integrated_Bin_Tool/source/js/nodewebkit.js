
// @ifdef nw
// Load native UI library
var gui = require('nw.gui'); //or global.window.nwDispatcher.requireNwGui() (see https://github.com/rogerwang/node-webkit/issues/707)
//var keypress = require('keypress');
// Get the current window
var win = gui.Window.get();
var NodeWebkitControl = {};

// prevent default behavior from changing page on dropped file
window.ondragover = function(e) { e.preventDefault(); return false };
window.ondrop = function(e) { e.preventDefault(); return false };

NodeWebkitControl.minimizeWindow = function() {
	win.minimize();
};

NodeWebkitControl.maximizeWindow = function() {
	win.toggleFullscreen();
};

NodeWebkitControl.closeWindow = function() {
    //win.emit('plugin_close');
    
    /* "closePluginWin" - Fix for TFS Bug 41940:PPC3 MAC - App crashes on maximize 
     * ISSUE - 
     * 1) Causing crash on closing the App in fullscreen in OSX ElCapitan platform 
     * 2) Causing crash if we do multiple force close on PPC3 Plugin window and Appcenter window
     * FIX - 
     * If app is closing in fullscreen mode, then leave fullscreen before closing the APP
     * To avoid multiple force close, manage the code to call force close only once 
     * For Plugin window, the force close is getting called inside PPC3 Plugin code
     * For Appcenter window, the force close is getting called inside PPC3 Appcenter code
     */
    
    if(win.isFullscreen) {
        win.leaveFullscreen();
    }
	win.close();
};
/*win.on('close', function() {
    fs.writeFile('message.txt', 'Hello Node', function (err) {
      if (err) throw err;
      console.log('It\'s saved!');
        win.close(true);
    });
});*/
// $(document).ready(function(){
                 
//     var windowWidth = $(window).width();
//     //alert(windowWidth);
//     var maxControl = $('.mmc-controls-holder:eq(1)');
//     if(windowWidth <= 1200){
//         $(maxControl).removeClass('app-maximize').addClass('app-maximize-small');
//     }
//     else {
//         $(maxControl).removeClass('app-maximize-small').addClass('app-maximize');
        
//     }           
                 
//  });

// $(document).on('click','.app-minimize',function(){
    
//     NodeWebkitControl.minimizeWindow();
        
// });

// var toggleMaximize = function(){
//     NodeWebkitControl.maximizeWindow();
//     var windowWidth = $(window).width();
//     if(windowWidth <= 1200){
//         $('.app-maximize-small').removeClass('app-maximize-small').addClass('app-maximize');
//     }
//     else {
//         $('.app-maximize').removeClass('app-maximize').addClass('app-maximize-small');
        
//     }
// }

// $(document).on('click','.app-maximize-small,.app-maximize',function(){
//     toggleMaximize();
// });

// @endif
// make `process.stdin` begin emitting "keypress" events
/*keypress(process.stdin);

// listen for the "keypress" event
process.stdin.on('keypress', function (ch, key) {
  if (key && key.name == "f12") {
  	if(!win.isDevToolsOpen)
    	win.showDevTools();
  }
});*/

