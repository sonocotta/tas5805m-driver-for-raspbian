/*
*FileOps.js will handle all file related operations in PPC3
*
*
*
*/

var fs = require('fs');
// @ifdef chartests
// <!-- comments:uncomment // -->
// var Promise = require('promise');
// <!-- endcomments -->
// @endif

// @ifdef nw
// <!-- comments:uncomment // -->
// var Promise = require('promise');
// <!-- endcomments -->
// @endif


var fileOps = {};

fileOps.readJSONFile = function (path, callback) {
    return new Promise(function (fulfill, reject){
        fs.readFile(path, 'utf8',function (err, data) {
           if (err) {
              reject(err);
            }
            else {
                try {
                    var jsonDataArray = [];
                    /*var dataArray = data.split('\n');
                    for (var line in dataArray) {
                        jsonDataArray.push(JSON.parse(dataArray[line]));
                    }*/
                    jsonDataArray.push(JSON.parse(data));
                    fulfill(jsonDataArray);
                }
                catch (err) {
                    reject("Not a valid JSON");
                }
            }
			
        });
    });
};

fileOps.readFile = function (path) {
    return new Promise(function (fulfill, reject){
        fs.readFile(path, 'utf8',function (err, data) {
           if (err) {
              reject(err);
            }
            else {
				fulfill(data);
            }
			
        });
    });
};

fileOps.writeToFile = function(path, data){
    return new Promise(function(fulfill,reject){
        fs.writeFile(path,data,function(err){
            if(err){
                reject(err);
            } else {
                fulfill();
            }
        });
    });
};

if(typeof module !="undefined" && module.exports){
	module.exports = fileOps;
}



